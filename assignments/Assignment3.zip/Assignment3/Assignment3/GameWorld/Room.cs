﻿using Assignment3.GameObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.GameWorld
{
    public class Room
    {
        protected string name;
        protected string description;
        protected World world;

        protected Room north;
        protected Room south;
        protected Room east;
        protected Room west;

        protected List<AbstractObject> objects;

        public Room(string roomName, string description, World world)
        {
            name = roomName;
            this.description = description;
            this.world = world;
            objects = new List<AbstractObject>();
        }

        public void AddToRoom(AbstractObject obj)
        {
            throw new NotImplementedException();
        }

        public void RemoveFromRoom(AbstractObject obj)
        {
            throw new NotImplementedException();
        }

        public void AddNeighbor(Room room, Directions direction)
        {
            throw new NotImplementedException();
        }

        public AbstractObject GetObjectWithName(string name)
        {
            throw new NotImplementedException();
        }

        public virtual List<string> GetObjectNames()
        {
            throw new NotImplementedException();
        }

        public List<string> GetDirections()
        {
            throw new NotImplementedException();
        }

        public Room GetNeighbor(Directions direction)
        {
            throw new NotImplementedException();
        }

        public List<AbstractObject> GetObjects()
        {
            return objects;
        }

        public string GetName()
        {
            return name;
        }
    }
}
