﻿using Assignment3.GameObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.GameWorld
{
    public class ObjectFactory
    {
        public ObjectFactory() { }

        public AbstractObject CreateObject(string actorType, string name, string description)
        {
            throw new NotImplementedException();
        }
    }
}
