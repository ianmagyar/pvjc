﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.GameObjects
{
    public class Cage : AbstractObject
    {
        private bool locked;
        private IPrince captive;

        public Cage(string name, string description) : base(name, description)
        {

        }

        public void Open()
        {
            throw new NotImplementedException();
        }
    }
}
