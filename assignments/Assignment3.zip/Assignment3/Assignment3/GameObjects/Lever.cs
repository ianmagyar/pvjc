﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.GameObjects
{
    public class Lever : AbstractObject, IUsable
    {
        private bool active;
        private Spikes spikes;

        public Lever(string name, string description, Spikes spikes) : base(name, description)
        {
            ConnectSpikes(spikes);
        }

        public void ConnectSpikes(Spikes spikes)
        {
            throw new NotImplementedException();
        }

        public void Use()
        {
            throw new NotImplementedException();
        }

        public bool WasUsed()
        {
            throw new NotImplementedException();
        }
    }
}
