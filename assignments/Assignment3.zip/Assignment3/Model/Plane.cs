﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.Model
{
    public class Plane
    {
        private int length;
        private List<Passenger>[,] seats;

        public Plane(int length)
        {

        }

        public void PrintPlane()
        {
            for (int x = 0; x < 7; x++)
            {
                if (x != 3)
                {
                    PrintSeats(x);
                }
                else
                {
                    PrintCorridor();
                }
            }
        }

        public void PrintSeats(int seatId)
        {
            string rowStr = "  | ";
            for (int j = 1; j < length + 1; j++)
            {
                if (seats[seatId, j].Count == 0)
                {
                    rowStr += " O";
                }
                else
                {
                    rowStr += $" {seats[seatId, j].Count}";
                }
            }
            System.Console.WriteLine(rowStr); // change to Debug if needed
        }

        public void PrintCorridor()
        {
            string corridorStr = "  ";
            for (int j = 0; j < length + 2; j++)
            {
                if (seats[3, j].Count == 0)
                {
                    corridorStr += "  ";
                }
                else
                {
                    corridorStr += $" {seats[3, j].Count}";
                }
            }
            System.Console.WriteLine(corridorStr); // change to Debug if needed
        }

        public void AddPassengers(List<Passenger> passengerList)
        {

        }

        public bool IsEmpty(int row, int col)
        {
            return false;
        }

        public void MoveRow(int row, char seat)
        {

        }

        public void ReturnRow(int row)
        {

        }

        public void MovePassengers()
        {

        }

        public bool BoardingFinished()
        {
            return false;
        }
    }
}
