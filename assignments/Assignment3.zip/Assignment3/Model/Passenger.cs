﻿namespace Assignment3.Model
{
    public class Passenger
    {
        private int row;
        private char seat;
        private int bags;

        private Plane plane;
        private Position currentPosition;

        public Passenger(int row, char seat, int bagNo)
        {

        }

        public Position? GetPosition()
        {
            return null;
        }

        public Position GetSeatPosition()
        {
            return new Position(0, 0);
        }
        public void AddToPlane(Plane plane)
        {

        }

        public void ForcedToMove(int x, int y)
        {

        }

        public bool CanSit()
        {
            return false;
        }

        public Position Move()
        {
            return new Position(0, 0);
        }
    }
}
