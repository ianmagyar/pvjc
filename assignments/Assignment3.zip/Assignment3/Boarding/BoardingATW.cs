﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.Boarding
{
    public class BoardingATW : AbstractBoarding
    {
        public BoardingATW() : base()
        {

        }

        public override void GenerateBoarding(int planeLength)
        {
            
        }
    }
}
