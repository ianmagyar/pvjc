﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.Boarding
{
    public class BoardingSteffen : AbstractBoarding
    {
        public BoardingSteffen() : base()
        {

        }

        public override void GenerateBoarding(int planeLength)
        {
            
        }
    }
}
