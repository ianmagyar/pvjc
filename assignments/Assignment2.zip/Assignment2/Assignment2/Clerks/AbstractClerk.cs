﻿using Assignment2.Clients;
using Assignment2.Forms;

namespace Assignment2.Clerks
{
    public abstract class AbstractClerk
    {
        protected List<AgendaType> agendas;
        protected List<Client> queue;
        protected int speed;

        protected AbstractClerk(int speed, List<AgendaType> agendas)
        {

        }

        public bool FilterAgenda(Agenda agenda)
        {
            return false;
        }

        public int GetWaitingCount()
        {
            return 0;
        }

        public void HandleNext()
        {

        }

        public void HandleAgenda(Agenda agenda)
        {

        }

        public abstract int HandleClient(Client client, Agenda agenda);
    }
}
