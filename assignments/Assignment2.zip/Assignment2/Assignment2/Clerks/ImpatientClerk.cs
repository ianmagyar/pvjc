﻿using Assignment2.Forms;
using Assignment2.Clients;

namespace Assignment2.Clerks
{
    public class ImpatientClerk : AbstractClerk
    {
        private int limit;

        public ImpatientClerk(int speed, List<AgendaType> agendas, int limit) : base(speed, agendas)
        {
            
        }

        public override int HandleClient(Client client, Agenda agenda)
        {
            return 0;
        }
    }
}
