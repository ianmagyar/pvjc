﻿namespace Assignment2.Forms
{
    public class Form
    {
        private double difficulty;
        private bool filledOut;
        private string formTitle;
        private int handlingTime;

        public Form(string formTitle, double difficulty, int handlingTime)
        {
        }
    }
}
