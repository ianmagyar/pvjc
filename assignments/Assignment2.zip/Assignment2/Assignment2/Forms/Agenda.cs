﻿namespace Assignment2.Forms
{
    public class Agenda
    {
        private AgendaType type;
        private List<Form> forms;
        private bool handled;

        public Agenda(AgendaType type)
        {

        }

        public void AddForm(Form form)
        {

        }

        public void RemoveForm(Form form)
        {

        }

        public int CalculateTime()
        {
            return 0;
        }
    }
}
