﻿namespace Assignment2.Forms
{
    public enum AgendaType
    {
        Personal,
        Housing,
        Documents,
        Vehicles
    }
}
