﻿using Assignment2.Clerks;
using Assignment2.Forms;

namespace Assignment2.Clients
{
    public class Client
    {
        protected double ability;
        protected Agenda agenda;
        protected List<AbstractClerk> visited;

        public Client(double ability)
        {

        }

        public void FillOutForms(Agenda agenda)
        {

        }

        public virtual AbstractClerk SelectClerk(List<AbstractClerk> clerks)
        {
            return null;
        }

        public (AbstractClerk, int) SolveAgenda(Agenda agenda, List<AbstractClerk> clerks)
        {
            return (null, 0);
        }
    }
}
