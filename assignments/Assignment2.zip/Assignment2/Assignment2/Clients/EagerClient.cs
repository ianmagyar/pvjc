﻿using Assignment2.Clerks;

namespace Assignment2.Clients
{
    public class EagerClient : Client
    {
        public EagerClient(double ability) : base(ability)
        {
            
        }

        public override AbstractClerk SelectClerk(List<AbstractClerk> clerks)
        {
            return null;
        }
    }
}
