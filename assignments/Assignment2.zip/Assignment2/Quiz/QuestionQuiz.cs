﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2.Quiz
{
    public class QuestionQuiz
    {
        private List<AbstractQuestion> questions;
        private int length;
        private int current;

        public QuestionQuiz(int length)
        {
            
        }

        public void AddQuestion(AbstractQuestion question)
        {
            
        }

        public void Reset()
        {
            
        }

        public AbstractQuestion? GetNextQuestion()
        {
            return null;
        }
    }
}
