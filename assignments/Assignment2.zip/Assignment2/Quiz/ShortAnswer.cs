﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2.Quiz
{
    public class ShortAnswer : AbstractQuestion
    {
        private string answer;

        public ShortAnswer(QuestionType category, string question, int points, string answer) : base(category, question, points)
        {
            
        }

        public override bool EvaluateAnswer(string guess)
        {
            return false;
        }
    }
}
