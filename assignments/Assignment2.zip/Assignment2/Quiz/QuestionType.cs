﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2.Quiz
{
    public enum QuestionType
    {
        GENERAL,
        SPORTS,
        GEOGRAPHY,
        HISTORY,
        ARTS,
        LITERATURE,
        MATHS,
        PHYSICS,
        CHEMISTRY,
        ENTERTAINMENT
    }
}
