﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2.Quiz
{
    public class TestQuestion : AbstractQuestion
    {
        private List<string> options;
        private int correctId;

        public TestQuestion(QuestionType category, string question, int points) : base(category, question, points)
        {
            
        }

        public override bool EvaluateAnswer(string guess)
        {
            return false;
        }

        public void AddOption(string option)
        {
            
        }

        public void SetCorrect(int id)
        {
            
        }
    }
}
