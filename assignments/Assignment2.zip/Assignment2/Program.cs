﻿using Assignment2.Player;
using Assignment2.Quiz;

namespace Assignment2
{
    internal class Program
    {
        static List<QuizPlayer>? FindBestTeam(QuestionQuiz quiz, List<QuizPlayer> allPlayers, int count)
        {
            return null;
        }

        static List<List<QuizPlayer>>? FindDuos(QuestionQuiz quiz, List<QuizPlayer> allPlayers, int count)
        {
            return null;
        }

        static void Main(string[] args)
        {
            
        }
    }
}