﻿using Assignment2.Quiz;

namespace Assignment2.Player
{
    public class QuizPlayer
    {
        protected Dictionary<QuestionType, float> knowledgeLevel;

        public QuizPlayer(Dictionary<QuestionType, float> knowledgeLevel)
        {
            
        }

        public void SetKnowledgeLevel(QuestionType category, float knowledgeLevel)
        {
            
        }

        public virtual string GetGuess(AbstractQuestion question)
        {
            return "";
        }
    }
}
