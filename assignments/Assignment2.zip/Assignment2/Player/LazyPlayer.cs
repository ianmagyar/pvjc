﻿using Assignment2.Quiz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2.Player
{
    public class LazyPlayer : QuizPlayer
    {
        public LazyPlayer(List<QuestionType> interests) : base(new Dictionary<QuestionType, float>())
        {
            
        }

        public override string GetGuess(AbstractQuestion question)
        {
            return "";
        }
    }
}
