﻿using Assignment2.Quiz;

namespace Assignment2.Player
{
    public class KnowItAll : QuizPlayer
    {
        public KnowItAll(List<QuestionType> interests) : base(new Dictionary<QuestionType, float>())
        {
            
        }

        public override string GetGuess(AbstractQuestion question)
        {
            return "";
        }
    }
}
