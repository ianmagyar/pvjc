﻿namespace Assignment1
{
    public class Author
    {
        private string firstName;
        private string lastName;

        public Author(string firstName, string lastName)
        {
            
        }

        public void SetAuthorName(string firstName, string lastName)
        {
            
        }

        public string GetAuthorName()
        {
            return "";
        }
    }
}

