﻿namespace Assignment1
{
    internal class Program
    {
        static List<Recording> LoadRecordings(string path)
        {
            return new List<Recording>();
        }

        static List<Purchase> LoadPurchases(string path)
        {
            return new List<Purchase>();
        }

        static List<string> GetAllTitles(string path)
        {
            return new List<string>();
        }

        static string FindMostPopularPiece(string path)
        {
            return "";
        }

        static string FindMostPopularComposer(string path)
        {
            return "";
        }

        static string GetBestSellDay(string path)
        {
            return "";
        }

        static double GetAveragePiecePrice(string path, string title)
        {
            return 0.0;
        }

        static void Main(string[] args)
        {
            // write your code here for any tests you want to carry out

            // to test the class structures, use the following instructions:
            // StructureTest sTest = StructureTest.GetInstance();
            // sTest.CheckClasses();
        }
    }
}