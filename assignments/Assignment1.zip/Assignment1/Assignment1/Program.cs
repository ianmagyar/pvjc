﻿namespace Assignment1
{
    public class Program
    {
        // 1. load from file as a list of records (2p)
        static List<Record> LoadRecords(string path)
        {
            return null;
        }

        // 2. find title of most commonly borrowed book from records (0.5p)
        static string FindMostReadBook(string path)
        {
            return "";
        }

        // 3. find most read author (1p)
        static string FindMostReadAuthor(string path)
        {
            return "";
        }

        // 3. find most avid reader (0.5p)
        static int FindMostAvidReader(string path)
        {
            return 0;
        }

        // 4. calculate income to a given day (1p)
        static float CalculateIncome(string path, DateTime date)
        {
            return 0.0f;
        }

        static void Main(string[] args)
        {
            
        }
    }
}