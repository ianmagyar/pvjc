﻿namespace Assignment1
{
    public class Composer
    {
        private string firstName;
        private string lastName;

        public Composer(string firstName, string lastName)
        {

        }

        public string GetName()
        {
            return "";
        }

        public void SetName(string firstName, string lastName)
        {

        }
    }
}
