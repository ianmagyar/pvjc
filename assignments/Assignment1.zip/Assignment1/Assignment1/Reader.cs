﻿namespace Assignment1
{
    public class Reader
    {
        private string name;
        private int readerId;
        private float readingSpeed;
        private List<Record> reads;

        public Reader(string name, int readerId, float readingSpeed)
        {
            
        }

        public int GetTotalReadingTime()
        {
            return 0;
        }

        public void AddReading(Record record)
        {

        }

        public float ReturnBooks(DateTime date)
        {
            return 0.0f;
        }
    }
}
