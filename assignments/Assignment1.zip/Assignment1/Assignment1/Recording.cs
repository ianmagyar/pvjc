﻿namespace Assignment1
{
    public class Recording
    {
        private Piece piece;
        private string code;

        public Recording(Piece piece, string code)
        {

        }

        public string GetTitle()
        {
            return "";
        }
    }
}
