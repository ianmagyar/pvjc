﻿namespace Assignment1
{
    public class Purchase
    {
        private Recording recording;
        private DateTime time;
        private int amount;
        private double price;

        public Purchase(Recording recording, double price, int amount, DateTime time)
        {

        }

        public DateTime GetPurchaseDay()
        {
            return new DateTime();
        }

        public double GetTotal()
        {
            return 0.0;
        }
    }
}
