﻿namespace Assignment1
{
    public class Book
    {
        private string title;
        private int length;
        private Author author;

        public Book(string title, int length, string authorName)
        {
            
        }

        public int GetReadingTime(float minutesPerPage, bool inHours)
        {
            return 0;
        }
    }
}
