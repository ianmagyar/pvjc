﻿namespace Assignment1
{
    public class Record
    {
        private Book book;
        private Reader reader;
        private DateTime borrowed;
        private bool returned;

        public Record(Book book, Reader reader, DateTime borrowed)
        {
            
        }

        public float GetFee(DateTime date)
        {
            return 0.0f;
        }
    }
}
