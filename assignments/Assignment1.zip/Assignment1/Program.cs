﻿using Assignment1.Buyers;
using Assignment1.Shop;

namespace Assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Product laptop = new Product("laptop", 700, ProductType.Electronics);
            Product monitor = new Product("monitor", 400, ProductType.Electronics);
            Product desk = new Product("desk", 150, ProductType.Furniture);

            Store myStore = new Store(0.1);
            myStore.StockProduct(laptop, 10, 0);
            myStore.StockProduct(monitor, 5, 0.05);

            Store cheapStore = new Store(0.0);
            cheapStore.StockProduct(laptop, 10, 0);
            cheapStore.StockProduct(monitor, 5, 0.05);
            cheapStore.StockProduct(desk, 10, 0);

            List<Store> allStores = new List<Store>();
            allStores.Add(myStore);
            allStores.Add(cheapStore);

            List<ProductType> electroList = new List<ProductType>();
            electroList.Add(ProductType.Electronics);

            Card electronicsCard = new Card(electroList, 0.2);

            Buyer testBuyer = new EagerBuyer(electronicsCard, 2000);
            testBuyer.AddToWishList(laptop, 2);
            testBuyer.AddToWishList(desk, 1);

            testBuyer.VisitStores(allStores);

            Console.WriteLine(testBuyer.GetBudget());

            foreach (Product product in testBuyer.GetBought())
            {
                Console.WriteLine(product);
            }

            Buyer cheapBuyer = new CheapBuyer(electronicsCard, 2000);
            cheapBuyer.AddToWishList(laptop, 2);
            cheapBuyer.AddToWishList(desk, 1);

            cheapBuyer.VisitStores(allStores);

            Console.WriteLine(cheapBuyer.GetBudget());

            foreach (Product product in cheapBuyer.GetBought())
            {
                Console.WriteLine(product);
            }

            Buyer lazyBuyer = new LazyBuyer(electronicsCard, 2000, 1);
            lazyBuyer.AddToWishList(laptop, 2);
            lazyBuyer.AddToWishList(desk, 1);

            lazyBuyer.VisitStores(allStores);

            Console.WriteLine(lazyBuyer.GetBudget());

            foreach (Product product in lazyBuyer.GetBought())
            {
                Console.WriteLine(product);
            }*/
        }
    }
}