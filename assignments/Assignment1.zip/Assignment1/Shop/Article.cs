﻿namespace Assignment1.Shop
{
    public class Article
    {
        private Product product;
        private double incomeRate;
        private double discount;
        private int quantity;

        public Article(Product product, double incomeRate, int quantity, double discount)
        {
            this.product = product;
            this.incomeRate = incomeRate;
            this.quantity = quantity;
            this.discount = discount;
        }

        public double GetPrice()
        {
            return 0;
        }

        public void SetDiscount(double discount)
        {
            
        }

        public void SetIncomeRate(double incomeRate)
        {
            
        }

        public ProductType GetCategory()
        {
            return ProductType.Book;
        }

        public bool CanSell(int count)
        {
            return false;
        }

        public bool Sell(int count)
        {
            return false;
        }
    }
}
