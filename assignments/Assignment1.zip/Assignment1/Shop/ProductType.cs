﻿namespace Assignment1.Shop
{
    public enum ProductType
    {
        Book,
        Electronics,
        Drinks,
        Furniture,
        Toy,
        Game,
        Vinyl,
        Clothes,
        Sport,
        Pets
    }
}
