﻿using Assignment1.Buyers;

namespace Assignment1.Shop
{
    public class Store
    {
        private List<Article> articles = new List<Article>();
        private double incomeRate;
        private double income;

        public Store(double incomeRate)
        {
            this.incomeRate = incomeRate;
            this.income = 0;
        }
        public double GetIncome()
        {
            return 0;
        }

        public void StockProduct(Product product, int count, double discount)
        {
            
        }

        public void ApplyDiscountForCategory(ProductType category, double discount)
        {
            
        }

        public bool HasProduct(Product product, int count)
        {
            return false;
        }

        public double GetPrice(Product product, Card card)
        {
            return 0;
        }

        public void SellProduct(Product product, int count, Buyer buyer)
        {
            
        }
    }
}
