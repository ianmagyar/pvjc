﻿using Assignment1.Shop;

namespace Assignment1.Buyers
{
    public class LazyBuyer : Buyer
    {
        private int storeCount;

        public LazyBuyer(Card card, double budget, int storeCount) : base(card, budget)
        {
            this.storeCount = storeCount;
        }
        public override void VisitStores(List<Store> stores)
        {
            
        }
    }
}
