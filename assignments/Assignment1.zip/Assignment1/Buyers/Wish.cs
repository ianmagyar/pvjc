﻿using Assignment1.Shop;

namespace Assignment1.Buyers
{
    public class Wish
    {
        private Product product;
        private int count;

        public Wish(Product product, int count)
        {
            this.product = product;
            this.count = count;
        }

        public bool Update(int bought)
        {
            return false;
        }
    }
}
