﻿using Assignment1.Shop;

namespace Assignment1.Buyers
{
    public abstract class Buyer
    {
        protected Card card;
        protected double budget;
        protected List<Wish> wishList;
        protected List<Product> hasBought;

        protected Buyer(Card card, double budget)
        {
            this.card = card;
            this.budget = budget;
            this.wishList = new List<Wish>();
            this.hasBought = new List<Product>();
        }

        public void AddToWishList(Product product, int count)
        {
            
        }

        public Card GetCard()
        {
            return null;
        }

        public double GetBudget()
        {
            return 0;
        }

        public List<Product> GetBought()
        {
            return null;
        }

        public bool CanAfford(double price, int count)
        {
            return false;
        }

        public bool Inquire(Store store, Wish wish)
        {
            return false;
        }

        public Wish FindWish(Product product)
        {
            return null;
        }

        public void SellTo(Product product, int count, double price)
        {
            
        }

        public abstract void VisitStores(List<Store> stores);
    }
}
