﻿using Assignment1.Shop;

namespace Assignment1.Buyers
{
    public class CheapBuyer : Buyer
    {
        public CheapBuyer(Card card, double budget) : base(card, budget)
        {
        }

        public override void VisitStores(List<Store> stores)
        {
            
        }
    }
}
