﻿using MyGame.Actors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Commands
{
    public class HealOverTime : ICommand
    {
        private int waitTime;
        private int healthChange;
        private int rounds;
        private int counter;
        private int applied;
        private int cost;

        private ICharacter toHeal;

        public HealOverTime(int seconds, int change, int rounds, int cost)
        {
            waitTime = seconds;
            this.healthChange = change;
            this.rounds = rounds;
            counter = 0;
            applied = 0;
            this.cost = cost;
        }

        public void SetTarget(ICharacter target)
        {
            toHeal = target;
        }

        public void Execute()
        {
            if (applied >= rounds)
                return;

            counter++;
            if (counter == waitTime * 30)  // FPS set to 30
            {
                if (toHeal != null)
                {
                    toHeal.ChangeHealth(healthChange);
                    applied++;
                }
                counter = 0;
            }
        }
    }
}
