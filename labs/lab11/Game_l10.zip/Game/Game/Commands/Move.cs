﻿using MyGame.Actors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Commands
{
    // Update in Task 3
    public class Move : ICommand
    {
        private IMovable actor;
        private int dx;
        private int dy;

        public Move(IMovable movable, int dx, int dy)
        {
            if (!(movable is AbstractActor))
                throw new ArgumentException("Cannot move object, it is not AbstractCharacter");

            this.actor = movable;
            this.dx = dx;
            this.dy = dy;
        }

        public void Execute()
        {
            double speed = actor.GetSpeed();

            AbstractActor aActor = (actor as AbstractActor);
            double newX = aActor.GetX() + (speed * dx);
            double newY = aActor.GetY() + (speed * dy);
            if (!aActor.GetWorld().IntersectsWithWall(aActor))
                aActor.SetPosition(newX, newY);
        }

        public void SetTarget(ICharacter target)
        {
            
        }
    }
}
