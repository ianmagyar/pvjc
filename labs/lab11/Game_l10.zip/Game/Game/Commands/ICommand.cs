﻿using MyGame.Actors;

namespace MyGame.Commands
{
    public interface ICommand
    {
        void Execute();

        void SetTarget(ICharacter target);
    }
}
