﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MyGame.Worlds;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Actors
{
    public abstract class AbstractActor : IActor
    {
        protected string name;
        protected Vector2 position;
        protected Texture2D texture;
        protected IWorld world;
        protected bool affectedByPhysics;
        protected bool toBeRemoved;

        protected AbstractActor()
        {
            name = "";
        }

        protected AbstractActor(string name)
        {
            this.name = name;
        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(texture, position, Color.White);
            spriteBatch.End();
        }

        public virtual int GetHeight()
        {
            return texture.Height;
        }

        public string GetName()
        {
            return this.name;
        }

        public Texture2D GetTexture()
        {
            return texture;
        }

        public virtual int GetWidth()
        {
            return texture.Width;
        }

        public IWorld GetWorld()
        {
            return world;
        }

        public double GetX()
        {
            return position.X;
        }

        public double GetY()
        {
            return position.Y;
        }

        public bool IntersectsWithActor(IActor other)
        {
            return !(other.GetX() > this.GetX() + this.GetWidth()
                     || other.GetX() + other.GetWidth() < this.GetX()
                     || other.GetY() > this.GetY() + this.GetHeight()
                     || other.GetY() + other.GetHeight() < this.GetY());
        }

        public bool IsAffectedByPhysics()
        {
            return affectedByPhysics;
        }

        // Task 1.1
        public void OnAddedToWorld(IWorld world)
        {
            this.world = world;
        }

        public bool RemovedFromWorld()
        {
            return toBeRemoved;
        }

        public void RemoveFromWorld()
        {
            toBeRemoved = true;
        }

        public void SetName(string name)
        {
            this.name = name;
        }

        public void SetPhysics(bool isPhysicsEnabled)
        {
            affectedByPhysics = isPhysicsEnabled;
        }

        public void SetPosition(double posX, double posY)
        {
            position = new Vector2((float)posX, (float)posY);
        }

        public void SetTexture(Texture2D texture)
        {
            this.texture = texture;
        }

        public virtual void Update(GameTime gameTime)
        {

        }
    }
}
