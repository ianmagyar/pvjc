﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace MyGame.Actors
{
    public class LightBulb : AbstractSwitchable, IObserver
    {
        private PowerSwitch pSwitch;

        public LightBulb(string name, ContentManager content, Vector2 position, PowerSwitch pSwitch) : base(name)
        {
            offTexture = content.Load<Texture2D>("bulb_off");
            onTexture = content.Load<Texture2D>("bulb_on");
            SetTexture(offTexture);

            SetPosition((int)position.X, (int)position.Y);
            isOn = false;

            this.AddPowerSwitch(pSwitch);
        }

        public void AddPowerSwitch(PowerSwitch pSwitch)
        {
            this.pSwitch = pSwitch;
            if (this.pSwitch != null)
            {
                this.pSwitch.Subscribe(this);
                this.isOn = this.pSwitch.IsOn();
                if (this.isOn)
                    SetTexture(onTexture);
                else
                    SetTexture(offTexture);
            }
        }

        public void Notify(IObservable observable)
        {
            if ((observable as PowerSwitch).IsOn())
                TurnOn();
            else
                TurnOff();
        }
    }
}
