﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.Threading;

namespace MyGame.Actors
{
    public class Bomb : AbstractAnimatedActor
    {
        private float timer;
        private const float TIMER = 0.25f;

        public Bomb(string name, ContentManager content, Vector2 position) : base(name, content.Load<Texture2D>("bomb"), 1, 2)
        {
            timer = TIMER;
            SetPosition((int)position.X, (int)position.Y);
        }

        public override void Update(GameTime gameTime)
        {
            float elapsed = (float)gameTime.ElapsedGameTime.TotalSeconds;
            timer -= elapsed;
            if (timer < 0)
            {
                timer = TIMER;
                currentFrame++;
                if (currentFrame == totalFrames)
                    currentFrame = 0;
            }
        }
    }
}
