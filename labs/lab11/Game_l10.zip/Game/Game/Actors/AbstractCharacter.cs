﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MyGame.Commands;
using MyGame.Strategies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Actors
{
    // Task 2
    public abstract class AbstractCharacter : AbstractAnimatedActor, ICharacter
    {
        protected double speed;
        protected int health;
        protected List<ICommand> effects;
        protected ISpeedStrategy speedStrategy;

        protected AbstractCharacter(string name, Texture2D texture, int rows, int columns, double speed) : base(name, texture, rows, columns)
        {
            this.speed = speed;
            health = 100;
            effects = new List<ICommand>();
        }

        public void AddEffect(ICommand effect)
        {
            effects.Add(effect);
        }

        public void ChangeHealth(int delta)
        {
            health += delta;
            if (health > 100)
                health = 100;
            if (health < 0)
                health = 0;

            if (health <= 0)
                Die();
        }

        public void Die()
        {
            RemoveFromWorld();
        }

        public double GetBaseSpeed()
        {
            return speed;
        }

        public int GetHealth()
        {
            return health;
        }

        public double GetSpeed()
        {
            return speedStrategy.GetSpeed(speed);
        }

        public void RemoveEffect(ICommand effect)
        {
            if (effects.Contains(effect))
                effects.Remove(effect);
        }

        public void SetSpeedStrategy(ISpeedStrategy strategy)
        {
            speedStrategy = strategy;
        }

        public ISpeedStrategy GetSpeedStrategy()
        {
            return speedStrategy;
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            foreach (ICommand effect in effects)
            {
                effect.Execute();
            }
        }
    }
}
