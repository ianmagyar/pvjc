﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;

namespace MyGame.Actors
{
    public class CrackedLightBulb : LightBulb
    {
        private int turnOnTimes;
        private int turnedOn;

        public CrackedLightBulb(string name, ContentManager content, Vector2 position, PowerSwitch pSwitch, int turnOnTimes) : base(name, content, position, pSwitch)
        {
            this.turnOnTimes = turnOnTimes;
            turnedOn = 0;
        }

        public override void TurnOn()
        {
            if (turnedOn < turnOnTimes)
            {
                turnedOn++;
                base.TurnOn();
            }
        }
    }
}
