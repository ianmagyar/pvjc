﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MyGame.Worlds;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Actors
{
    public interface IActor
    {
        string GetName();

        void SetName(string name);

        double GetX();

        double GetY();

        int GetHeight();

        int GetWidth();

        void SetPosition(double posX, double posY);

        void OnAddedToWorld(IWorld world);

        IWorld GetWorld();

        Texture2D GetTexture();

        void SetTexture(Texture2D texture);

        bool IntersectsWithActor(IActor other);

        void SetPhysics(bool isPhysicsEnabled);

        bool IsAffectedByPhysics();

        void RemoveFromWorld();

        bool RemovedFromWorld();

        void Update(GameTime gameTime);

        void Draw(SpriteBatch spriteBatch);
    }
}
