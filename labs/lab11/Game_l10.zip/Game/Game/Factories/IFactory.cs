﻿using Microsoft.Xna.Framework.Content;
using MyGame.Actors;
using System;

namespace MyGame.Factories
{
    public interface IFactory
    {
        IActor Create(String actorType, String actorName, int x, int y);
    }
}
