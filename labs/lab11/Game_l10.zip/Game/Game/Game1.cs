﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MyGame.Actors;
using MyGame.Factories;
using MyGame.Utils;
using MyGame.Worlds;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using TiledCS;

namespace MyGame
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        private SpriteFont healthFont;
                
        private Bomb bomb;
        private LightBulb bulb;
        private PowerSwitch powerSwitch;

        private LightBulb bulb2;
        private LightBulb bulb3;

        private Player player;
        private GameWorld world;
        private WorldMap map;
        

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;

            TargetElapsedTime = TimeSpan.FromSeconds(1d / 30d);
            world = new GameWorld(592, 800);
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            _graphics.IsFullScreen = false;
            _graphics.PreferredBackBufferWidth = 800;
            _graphics.PreferredBackBufferHeight = 592;
            _graphics.ApplyChanges();

            base.Initialize();
        }

        protected override void LoadContent()
        {
            ActorFactory aFactory = new ActorFactory(Content);
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            healthFont = Content.Load<SpriteFont>("Health");

            map = new WorldMap(Content.RootDirectory + "\\map01.tmx", Content.RootDirectory + "\\tileset_basic.tsx", "tileset_basic", Content, world, aFactory);
        }

        protected override void Update(GameTime gameTime)
        {
            KeyChecker.GetState();
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();


            // TODO: Add your update logic here
            world.Update(gameTime);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            map.DrawMap(_spriteBatch);

            // TODO: Add your drawing code here
            world.Draw(_spriteBatch);

            Player player = world.GetActor("Player") as Player;
            if (player != null)
            {
                _spriteBatch.Begin();
                _spriteBatch.DrawString(healthFont, "Health: " + player.GetHealth(), new Vector2(40, 35), Color.White);
                _spriteBatch.End();
            }

            base.Draw(gameTime);
        }
    }
}