﻿using MyGame.Actors;
using MyGame.Commands;
using System;
using System.Collections.Generic;

namespace MyGame.Spells
{
    public class SelfCastSpell : ISpell
    {
        private IWizard wizard;
        private IEnumerable<ICommand> effects;
        private int cost;

        public SelfCastSpell(IWizard wizard, IEnumerable<ICommand> effects, int cost)
        {
            this.wizard = wizard;
            this.effects = effects;
            this.cost = cost;
        }

        public ISpell AddEffect(ICommand effect)
        {
            (effects as List<ICommand>).Add(effect);
            return this;
        }

        public void AddEffects(IEnumerable<ICommand> effects)
        {
            this.effects = effects;
        }

        public void ApplyEffects(ICharacter target)
        {
            foreach (ICommand effect in effects)
            {
                effect.SetTarget(target);
                target.AddEffect(effect);
            }
        }

        public int GetCost()
        {
            return (int)Math.Round(cost * 0.75);
        }
    }
}
