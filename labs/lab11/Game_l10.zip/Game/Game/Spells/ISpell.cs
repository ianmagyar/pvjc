﻿using MyGame.Actors;
using MyGame.Commands;
using System.Collections.Generic;

namespace MyGame.Spells
{
    public interface ISpell
    {
        ISpell AddEffect(ICommand effect);
        void AddEffects(IEnumerable<ICommand> effects);
        int GetCost();
        void ApplyEffects(ICharacter target);
    }
}
