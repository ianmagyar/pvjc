﻿using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

namespace MyGame.Spells
{
    public class SpellDirector : ISpellDirector
    {
        private Dictionary<string, int> effectCosts;
        private Dictionary<string, SpellInfo> spells;

        private ISpellBuilder projectileBuilder;
        private ISpellBuilder selfCastBuilder;
        private SpellDataProvider provider;

        private IWizard wizard;
        private ContentManager content;

        public SpellDirector(IWizard wizard, ContentManager content)
        {
            provider = SpellDataProvider.GetInstance();
            effectCosts = provider.GetSpellEffects();
            spells = provider.GetSpellInfo();

            projectileBuilder = new ProjectileSpellBuilder();
            selfCastBuilder = new SelfCastSpellBuilder();

            this.wizard = wizard;
            this.content = content;
        }

        public ISpell Build(string spellName)
        {
            SpellInfo spellInfo = spells[spellName];

            ISpellBuilder builder;
            if (spellInfo.SpellType == SpellType.ProjectileSpell)
            {
                builder = projectileBuilder;
                builder.SetTexture(content.Load<Texture2D>(spellInfo.TextureName));
            }
            else
            {
                builder = selfCastBuilder;
            }

            int totalCost = 0;
            foreach (string effect in spellInfo.EffectNames)
            {
                builder = builder.AddEffect(effect);
                totalCost += effectCosts[effect];
            }
            builder.SetSpellCost(totalCost);

            return builder.CreateSpell(wizard);
        }
    }
}
