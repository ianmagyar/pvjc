﻿using Microsoft.Xna.Framework.Graphics;
using MyGame.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Spells
{
    public class SelfCastSpellBuilder : ISpellBuilder
    {
        private int cost;
        private IList<ICommand> effects;

        private SpellEffectFactory factory;

        public SelfCastSpellBuilder()
        {
            factory = new SpellEffectFactory();
            effects = new List<ICommand>();
        }

        public ISpellBuilder AddEffect(string effectName)
        {
            effects.Add(factory.GetEffect(effectName));
            return this;
        }

        public ISpell CreateSpell(IWizard wizard)
        {
            return new SelfCastSpell(wizard, effects, cost);
        }

        public ISpellBuilder SetSpellCost(int cost)
        {
            this.cost = cost;
            return this;
        }

        public ISpellBuilder SetTexture(Texture2D animation)
        {
            return this;
        }
    }
}
