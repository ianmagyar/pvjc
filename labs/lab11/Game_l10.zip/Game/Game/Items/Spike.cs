﻿using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using MyGame.Actors;
using MyGame.Strategies;

namespace MyGame.Items
{
    public class Spike : AbstractActor
    {
        public Spike(string name, ContentManager content, Vector2 position) : base(name)
        {
            SetTexture(content.Load<Texture2D>("spike"));
            SetPosition((int)position.X, (int)position.Y);
        }

        public override void Update(GameTime gameTime)
        {
            IActor player = world.GetActor("Player");
            if (player != null && IntersectsWithActor(player))
            {
                (player as AbstractCharacter).ChangeHealth(-25);
                RemoveFromWorld();
            }
        }
    }
}
