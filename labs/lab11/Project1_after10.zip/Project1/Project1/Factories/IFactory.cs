﻿using Microsoft.Xna.Framework.Content;
using Project1.Actors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Factories
{
    public interface IFactory
    {
        IActor Create(ContentManager content, String actorType, String actorName, int x, int y);
    }
}
