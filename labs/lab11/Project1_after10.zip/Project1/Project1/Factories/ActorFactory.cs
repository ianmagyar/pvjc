﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Project1.Actors;
using Project1.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Factories
{
    public class ActorFactory : IFactory
    {
        public ActorFactory() { }

        public IActor Create(ContentManager content, string actorType, string actorName, int x, int y)
        {
            if (actorType == "Player")
            {
                return new Player(actorName, content, new Vector2(x, y));
            }
            if (actorType == "Bomb")
            {
                return new Bomb(actorName, content, new Vector2(x, y));
            }
            if (actorType == "PowerSwitch")
            {
                return new PowerSwitch(actorName, content, new Vector2(x, y));
            }
            if (actorType == "LightBulb")
            {
                return new LightBulb(actorName, content, new Vector2(x, y), null);
            }
            if (actorType == "CrackedLightBulb")
            {
                return new CrackedLightBulb(actorName, content, new Vector2(x, y), null, 5);
            }
            if (actorType == "Star")
            {
                return new Star(actorName, content, new Vector2(x, y));
            }
            if (actorType == "Spike")
            {
                return new Spike(actorName, content, new Vector2(x, y));
            }
            return null;
        }
    }
}
