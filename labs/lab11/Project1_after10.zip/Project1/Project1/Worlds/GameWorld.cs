﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Project1.Actors;
using Project1.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Worlds
{
    public class GameWorld : IWorld
    {
        private List<IActor> actors;
        private List<IActor> toBeRemoved;
        private List<IActor> toBeAdded;

        private int width;
        private int height;

        private Gravity gravity;

        public GameWorld(int width, int height)
        {
            actors = new List<IActor>();
            toBeAdded = new List<IActor>();
            toBeRemoved = new List<IActor>();
            this.width = width;
            this.height = height;

            gravity = new Gravity();
            gravity.SetWorld(this);
        }

        public void AddActor(IActor actor)
        {
            toBeAdded.Add(actor);
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            actors.ForEach(a => a.Draw(spriteBatch));
        }

        public IActor? GetActor(string name)
        {
            foreach (IActor actor in actors)
            {
                if (actor.GetName() == name)
                {
                    return actor;
                }
            }
            return null;
        }

        public List<IActor> GetActors()
        {
            return actors;
        }

        public int GetHeight()
        {
            return height;
        }

        public int GetWidth()
        {
            return width;
        }

        public void RemoveActor(IActor actor)
        {
            if (actors.Contains(actor))
            {
                actors.Remove(actor);
            }
            actor.RemoveFromWorld();
        }

        public void Update(GameTime gameTime)
        {
            foreach (IActor actor in toBeAdded)
            {
                actors.Add(actor);
                actor.OnAddedToWorld(this);
            }
            toBeAdded.Clear();

            foreach (IActor actor in actors)
            {
                if (actor.RemovedFromWorld())
                {
                    toBeRemoved.Add(actor);
                }
            }

            toBeRemoved.ForEach(a => RemoveActor(a));
            toBeRemoved.Clear();

            actors.ForEach(a => a.Update(gameTime));
            gravity.Execute();
        }
    }
}
