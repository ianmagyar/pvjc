﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Actors
{
    public class Bomb : AbstractAnimatedActor
    {
        private float timer;
        private const float TIMER = 0.5f;

        public Bomb(string name, ContentManager content, Vector2 position) : base(name, content.Load<Texture2D>("bomb"), 1, 2)
        {
            this.position = position;

            timer = TIMER;
        }

        public override void Update(GameTime gameTime)
        {
            timer -= (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (timer < 0)
            {
                timer = TIMER;
                currentFrame++;
                if (currentFrame == totalFrames)
                {
                    currentFrame = 0;
                }
            }
        }
    }
}
