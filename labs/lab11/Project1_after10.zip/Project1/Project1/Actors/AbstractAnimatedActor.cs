﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Actors
{
    public class AbstractAnimatedActor : AbstractActor
    {
        protected int rows;
        protected int columns;
        protected int currentFrame;
        protected int totalFrames;

        public AbstractAnimatedActor() : base() { }
        public AbstractAnimatedActor(string name) : base(name) { }

        public AbstractAnimatedActor(string name, Texture2D texture, int rows, int columns) : this(name)
        {
            SetTexture(texture);
            this.rows = rows;
            this.columns = columns;
            height = texture.Height / rows;
            width = texture.Width / columns;
            totalFrames = rows * columns;
            currentFrame = 0;
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            int row = currentFrame / columns;
            int col = currentFrame % columns;

            Rectangle sourceRectangle = new Rectangle(width * col, height * row, width, height);
            Rectangle destinationRectangle = new Rectangle(GetX(), GetY(), GetWidth(), GetHeight());

            // TODO: draw bomb using spriteBatch
            spriteBatch.Begin();
            spriteBatch.Draw(texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
