﻿using Project1.Actors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Commands
{
    public class Move : ICommand
    {
        private double dx;
        private double dy;
        private IMovable movable;

        public Move(IMovable movable, double dx, double dy)
        {
            if (!(movable is ICharacter))
            {
                throw new ArgumentException("Can only move Player");
            }
            this.movable = movable;
            this.dx = dx;
            this.dy = dy;
        }

        public void Execute()
        {
            (movable as AbstractCharacter).UpdatePosition(dx * movable.GetSpeed(), dy * movable.GetSpeed());
        }
    }
}
