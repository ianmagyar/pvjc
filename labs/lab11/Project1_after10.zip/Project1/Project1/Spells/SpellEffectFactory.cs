﻿using Project1.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Spells
{
    public class SpellEffectFactory
    {
        public ICommand GetEffect(string effectName)
        {
            if (effectName == "DoT-3x5")
            {
                return new DamageOverTime(1, -5, 3, 15);
            }
            else if (effectName == "DoT-3x10")
            {
                return new DamageOverTime(1, -10, 3, 30);
            }
            else if (effectName == "HoT-3x10")
            {
                return new HealOverTime(1, 10, 3, 30);
            }
            else if (effectName == "HoT-3x5")
            {
                return new HealOverTime(1, 5, 3, 30);
            }
            else if (effectName == "Heal-10")
            {
                return new Heal(10, 5);
            }
            else if (effectName == "Heal-20")
            {
                return new Heal(20, 10);
            }
            else if (effectName == "SpeedChange-10")
            {
                return new SpeedChange(10, 5);
            }
            else
            {
                return null;
            }
        }
    }
}
