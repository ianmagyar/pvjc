﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Project1.Actors;
using Project1.Commands;
using Project1.Strategies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Spells
{
    public class ProjectileSpell : AbstractActor, IMovable, ISpell
    {
        private IWizard caster;
        private IEnumerable<ICommand> effects;
        private int cost;
        private ICommand move;
        private bool used = false;

        public ProjectileSpell(IWizard caster, IEnumerable<ICommand> effects, int cost, Texture2D texture)
        {
            this.caster = caster;
            this.effects = effects;
            this.cost = cost;
            this.texture = texture;
        }

        public ISpell AddEffect(ICommand effect)
        {
            effects.Append(effect);
            return this;
        }

        public void AddEffects(IEnumerable<ICommand> effects)
        {
            foreach (ICommand effect in effects)
            {
                this.effects.Append(effect);
            }
        }

        public void ApplyEffects(ICharacter target)
        {
            foreach (ICommand effect in effects)
            {
                target.AddEffect(effect);
            }
        }

        public double GetBaseSpeed()
        {
            return 3;
        }

        public int GetCost()
        {
            return 10;
        }

        public double GetSpeed()
        {
            return GetBaseSpeed();
        }

        public void SetSpeedStrategy(ISpeedStrategy strategy)
        {
            
        }

        public void SetDirection(bool movingRight)
        {
            if (movingRight)
                move = new Move(this, 1, 0);
            else
                move = new Move(this, -1, 0);
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            if (move != null)
                move.Execute();

            if (used)
                return;

            foreach (IActor actor in world.GetActors())
            {
                if (IntersectsWithActor(actor))
                {
                    if (actor is ICharacter)
                    {
                        ApplyEffects((actor as ICharacter));
                        used = true;
                        RemoveFromWorld();
                    }
                }
            }
        }
    }
}
