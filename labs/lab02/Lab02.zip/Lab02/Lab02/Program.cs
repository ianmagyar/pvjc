﻿using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

namespace Lab02
{
    internal class Program
    {
        static char[ , ] LoadSudoku(string problem)
        {
            char[ , ] result = new char[9, 9];

            return result;
        }

        static void PrintSudoku(char[,] grid)
        {
            
        }

        static bool IsValid(char[ , ] grid, int row, int col, char value)
        {
            return false;
        }

        static bool SolveSudoku(char[ , ] grid)
        {
            return false;
        }

        static void FillSure(char[ , ] grid)
        {

        }

        static void Main(string[] args)
        {
            string example1 = "632005400004001300000000567000273005021406080000510000060030900048050002100029800";

            char[,] grid = LoadSudoku(example1);
            PrintSudoku(grid);

            Console.WriteLine("\n\n\n");

            SolveSudoku(grid);
            PrintSudoku(grid);
        }
    }
}