﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Project1.Worlds;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Actors
{
    public class AbstractActor : IActor
    {
        protected string name;
        protected Vector2 position;
        protected int height;
        protected int width;
        protected IWorld world;
        protected Texture2D texture;
        protected bool affectedByPhysics;
        protected bool toBeRemoved;

        public AbstractActor()
        {
            name = "";
        }

        public AbstractActor(string name)
        {
            this.name = name;
        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(texture, position, Color.White);
            spriteBatch.End();
        }

        public int GetHeight()
        {
            return height;
        }

        public string GetName()
        {
            return name;
        }

        public Texture2D GetTexture()
        {
            return texture;
        }

        public int GetWidth()
        {
            return width;
        }

        public IWorld GetWorld()
        {
            return world;
        }

        public int GetX()
        {
            return (int)position.X;
        }

        public int GetY()
        {
            return (int)position.Y;
        }

        public bool IntersectsWithActor(IActor other)
        {
            int x1 = Math.Max(GetX(), other.GetX());
            int x2 = Math.Min(GetX() + GetWidth(), other.GetX() + other.GetWidth());
            int y1 = Math.Max(GetY(), other.GetY());
            int y2 = Math.Min(GetY() + GetHeight(), other.GetY() + other.GetHeight());

            return (x2 >= x1 && y2 >= y1);
        }

        public bool IsAffectedByPhysics()
        {
            return affectedByPhysics;
        }

        public void OnAddedToWorld(IWorld world)
        {
            this.world = world;
        }

        public bool RemovedFromWorld()
        {
            return toBeRemoved;
        }

        public void RemoveFromWorld()
        {
            toBeRemoved = true;
        }

        public void SetName(string name)
        {
            this.name = name;
        }

        public void SetPhysics(bool isPhysicsEnabled)
        {
            affectedByPhysics = isPhysicsEnabled;
        }

        public void SetPosition(int posX, int posY)
        {
            position = new Vector2(posX, posY);
        }

        public void SetTexture(Texture2D texture)
        {
            this.texture = texture;
        }

        public virtual void Update(GameTime gameTime)
        {
            
        }

        public void UpdatePosition(double dx, double dy)
        {
            position.X += (float)dx;
            position.Y += (float)dy;
        }
    }
}
