﻿using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Actors
{
    public abstract class AbstractSwitchable : AbstractActor, ISwitchable
    {
        protected Texture2D onTexture;
        protected Texture2D offTexture;
        protected bool turnedOn;

        protected AbstractSwitchable(string name) : base(name)
        {
            turnedOn = false;
        }

        public bool IsOn()
        {
            return turnedOn;
        }

        public virtual void Toggle()
        {
            if (turnedOn)
            {
                TurnOff();
            }
            else
            {
                TurnOn();
            }
        }

        public virtual void TurnOn()
        {
            if (!turnedOn)
            {
                turnedOn = true;
                texture = onTexture;
            }
        }

        public void TurnOff()
        {
            if (turnedOn)
            {
                turnedOn = false;
                texture = offTexture;
            }
        }
    }
}
