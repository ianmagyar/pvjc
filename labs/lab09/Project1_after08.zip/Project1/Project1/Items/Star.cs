﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Project1.Actors;
using Project1.Strategies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Items
{
    public class Star : AbstractActor
    {
        public Star(string name, ContentManager contentManager, Vector2 position) : base(name)
        {
            texture = contentManager.Load<Texture2D>("star");
            this.position = position;
        }

        public override void Update(GameTime gameTime)
        {
            IActor player = world.GetActor("player");
            if (player == null)
            {
                return;
            }

            if (IntersectsWithActor(player))
            {
                (player as AbstractCharacter).SetSpeedStrategy(new ModifiedSpeedStrategy());
                RemoveFromWorld();
            }
        }
    }
}
