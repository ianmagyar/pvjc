﻿namespace Game.Actors
{
    public interface IMovable
    {
    }
}
