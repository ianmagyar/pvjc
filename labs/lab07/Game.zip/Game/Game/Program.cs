﻿using Game.Actors;
using Game.Commands;
using Merlin2d.Game;

namespace Game
{
    internal class Program
    {
        static void Main(string[] args)
        {
            GameContainer container = new GameContainer("Game window", 500, 500); //constructor, creates new instance of the game

            //Cauldron cauldron = new Cauldron(100, 100, 63);

            //Stove stove = new Stove(100, 200, null);
            //stove.AddCauldron(cauldron);
            // stove.AddWood();
            // stove.AddWood();
            
            //container.GetWorld().AddActor(cauldron);
            //container.GetWorld().AddActor(stove);

            PowerSource source = new PowerSource(300, 200);
            Crystal crystal = new Crystal(source, 200, 200);
            Crystal crystal2 = new Crystal(null, 100, 200);

            CrackedCrystal crystal3 = new CrackedCrystal(source, 400, 200, 3);

            container.GetWorld().AddActor(crystal);
            container.GetWorld().AddActor(crystal2);
            container.GetWorld().AddActor(crystal3);
            container.GetWorld().AddActor(source);

            Player player = new Player(100, 300, 2);
            player.SetPhysics(true);
            container.GetWorld().AddActor(player);
            container.GetWorld().SetPhysics(new Gravity());

            Console.WriteLine(player.IsAffectedByPhysics());

            // crystal.Toggle();
            // source.Toggle();

            container.SetMap("resources/maps/map01.tmx");

            container.Run(); //start the game, infinite loop, no change is accepted after this until the game ends
        }
    }
}