﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Actors
{
    public class PowerSwitch : ISwitchable, IObservable
    {
        private Texture2D onTexture;
        private Texture2D offTexture;
        private Texture2D texture;
        private bool turnedOn;
        private Vector2 position;
        private List<IObserver> observers;

        public PowerSwitch(ContentManager contentManager, Vector2 position)
        {
            this.position = position;
            onTexture = contentManager.Load<Texture2D>("switch_on");
            offTexture = contentManager.Load<Texture2D>("switch_off");
            texture = offTexture;
            turnedOn = false;
            observers = new List<IObserver>();
        }

        public void Toggle()
        {
            turnedOn = !turnedOn;
            if (turnedOn)
            {
                texture = onTexture;
            }
            else
            {
                texture = offTexture;
            }
            foreach (IObserver observer in observers)
            {
                observer.Notify();
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(texture, position, Color.White);
            spriteBatch.End();
        }

        public void Update(GameTime gameTime)
        {
            if (KeyChecker.HasBeenPressed(Keys.E))
            {
                Toggle();
            }
        }

        public void TurnOn()
        {
            if (!turnedOn)
            {
                Toggle();
            }
        }

        public void TurnOff()
        {
            if (turnedOn)
            {
                Toggle();
            }
        }

        public bool IsOn()
        {
            return turnedOn;
        }

        public void Subscribe(IObserver observer)
        {
            if (!observers.Contains(observer))
            {
                observers.Add(observer);
            }
        }

        public void Unsubscribe(IObserver observer)
        {
            if (observers.Contains(observer))
            {
                observers.Remove(observer);
            }
        }
    }
}
