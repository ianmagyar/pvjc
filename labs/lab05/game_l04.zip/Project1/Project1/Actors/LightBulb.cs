﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Actors
{
    public class LightBulb : ISwitchable, IObserver
    {
        private Texture2D onTexture;
        private Texture2D offTexture;
        private Texture2D texture;
        private bool turnedOn;
        private Vector2 position;

        public LightBulb(ContentManager contentManager, Vector2 position)
        {
            this.position = position;
            onTexture = contentManager.Load<Texture2D>("bulb_on");
            offTexture = contentManager.Load<Texture2D>("bulb_off");
            texture = offTexture;
            turnedOn = false;
        }

        public void Toggle()
        {
            turnedOn = !turnedOn;
            if (turnedOn)
            {
                texture = onTexture;
            }
            else
            {
                texture = offTexture;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(texture, position, Color.White);
            spriteBatch.End();
        }

        public void TurnOn()
        {
            turnedOn = true;
            texture = onTexture;
        }

        public void TurnOff()
        {
            turnedOn = false;
            texture = offTexture;
        }

        public bool IsOn()
        {
            return turnedOn;
        }

        public void Notify()
        {
            Toggle();
        }
    }
}
