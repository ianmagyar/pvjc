﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MyGame.Actors;
using MyGame.Utils;

namespace MyGame
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
                
        private Bomb bomb;
        // Task 1.1
        private LightBulb bulb;
        // Task 1.2
        private PowerSwitch powerSwitch;

        // Task 3
        private LightBulb bulb2;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            bomb = new Bomb(Content);

            // Task 1.1
            bulb = new LightBulb(Content, new Vector2(400, 100));
            // Task 1.2
            powerSwitch = new PowerSwitch(Content, new Vector2(100, 300));

            // Task 1.3
            // bulb.TurnOn();
            // powerSwitch.TurnOn();

            // Task 2
            powerSwitch.Subscribe(bulb);
            // powerSwitch.Toggle();

            // Task 3
            bulb2 = new LightBulb(Content, new Vector2(500, 100));
            powerSwitch.Subscribe(bulb2);
        }

        protected override void Update(GameTime gameTime)
        {
            KeyChecker.GetState();
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();


            // TODO: Add your update logic here
            bomb.Update(gameTime);

            // Task 3
            powerSwitch.Update(gameTime);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            bomb.Draw(_spriteBatch, new Vector2(200, 200));
            // Task 1.1
            bulb.Draw(_spriteBatch);
            // Task 1.2
            powerSwitch.Draw(_spriteBatch);

            // Task 3
            bulb2.Draw(_spriteBatch);

            base.Draw(gameTime);
        }
    }
}