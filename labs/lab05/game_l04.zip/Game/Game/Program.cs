﻿
using var game = new MyGame.Game1();
game.Run();
