﻿namespace MyGame.Actors
{
    public interface IObserver
    {
        void Notify();
    }
}
