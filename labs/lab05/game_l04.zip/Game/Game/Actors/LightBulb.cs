﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace MyGame.Actors
{
    // Task 1.1
    public class LightBulb : ISwitchable, IObserver
    {
        private Texture2D texture;
        private Texture2D offTexture;
        private Texture2D onTexture;
        private Vector2 position;
        private bool isOn;

        public LightBulb(ContentManager content, Vector2 position)
        {
            offTexture = content.Load<Texture2D>("bulb_off");
            onTexture = content.Load<Texture2D>("bulb_on");
            texture = offTexture;

            this.position = position;
            isOn = false;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(texture, position, Color.White);
            spriteBatch.End();
        }

        public void Toggle()
        {
            isOn = !isOn;
            if (isOn)
                texture = onTexture;
            else
                texture = offTexture;
        }

        // Task 1.3
        public void TurnOn()
        {
            isOn = true;
            texture = onTexture;
        }

        // Task 1.3
        public void TurnOff()
        {
            isOn = false;
            texture = offTexture;
        }

        // Task 1.3
        public bool IsOn()
        {
            return isOn;
        }

        // Task 2
        public void Notify()
        {
            this.Toggle();
        }
    }
}
