﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MyGame.Utils;
using System.Collections.Generic;

namespace MyGame.Actors
{
    // Task 1.2
    public class PowerSwitch : ISwitchable, IObservable
    {
        private Texture2D texture;
        private Texture2D offTexture;
        private Texture2D onTexture;
        private Vector2 position;
        private bool isOn;

        // Task 2-3
        // private IObserver observer;

        // Task 4
        private List<IObserver> observers;

        public PowerSwitch(ContentManager content, Vector2 position)
        {
            offTexture = content.Load<Texture2D>("switch_off");
            onTexture = content.Load<Texture2D>("switch_on");
            texture = offTexture;

            this.position = position;
            isOn = false;

            // Task 4
            observers = new List<IObserver>();
        }
        
        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(texture, position, Color.White);
            spriteBatch.End();
        }

        public void Toggle()
        {
            if (isOn)
                TurnOff();
            else
                TurnOn();

            //if (this.observer != null)
            //    this.observer.Notify();

            foreach (IObserver observer in observers)
                observer.Notify();
        }

        // Task 1.3
        public void TurnOn()
        {
            isOn = true;
            texture = onTexture;
        }

        // Task 1.3
        public void TurnOff()
        {
            isOn = false;
            texture = offTexture;
        }

        // Task 1.3
        public bool IsOn()
        {
            return isOn;
        }

        // Task 2
        public void Subscribe(IObserver observer)
        {
            // this.observer = observer;
            observers.Add(observer);
        }

        // Task 2
        public void Unsubscribe(IObserver observer)
        {
            // this.observer = null;
            if (observers.Contains(observer))
                observers.Remove(observer);
        }

        // Task 3
        public void Update(GameTime gameTime)
        {
            if (KeyChecker.HasBeenPressed(Keys.E))
                Toggle();
        }
    }
}
