﻿using Game.Actors;
using Merlin2d.Game;

namespace Game
{
    internal class Program
    {
        static void Main(string[] args)
        {
            GameContainer container = new GameContainer("Game window", 500, 500); //constructor, creates new instance of the game

            //Cauldron cauldron = new Cauldron(100, 100, 63);

            //Stove stove = new Stove(100, 200, null);
            //stove.AddCauldron(cauldron);
            // stove.AddWood();
            // stove.AddWood();
            
            //container.GetWorld().AddActor(cauldron);
            //container.GetWorld().AddActor(stove);

            Crystal crystal = new Crystal(200, 200);
            PowerSource source = new PowerSource(300, 200);
            Crystal crystal2 = new Crystal(100, 200);

            source.Subscribe(crystal);
            source.Subscribe(crystal2);
            source.Unsubscribe(crystal);

            container.GetWorld().AddActor(crystal);
            container.GetWorld().AddActor(crystal2);
            container.GetWorld().AddActor(source);

            // crystal.Toggle();
            // source.Toggle();

            container.SetMap("resources/maps/map01.tmx");

            container.Run(); //start the game, infinite loop, no change is accepted after this until the game ends
        }
    }
}