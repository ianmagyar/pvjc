﻿using Merlin2d.Game;
using Merlin2d.Game.Actors;

namespace Game.Actors
{
    public class Crystal : AbstractActor, ISwitchable, IObserver
    {
        private Animation animation;
        private Animation onAnimation;
        private Animation offAnimation;

        private bool isOn = false;

        public Crystal(int x, int y)
        {
            this.onAnimation = new Animation("resources/crystal_on.png", 56, 56);
            this.offAnimation = new Animation("resources/crystal_off.png", 56, 56);

            this.UpdateAnimation(this.offAnimation);
            this.SetPosition(x, y);
        }

        private void UpdateAnimation(Animation animation)
        {
            this.animation = animation;
            this.SetAnimation(this.animation);
            this.animation.Start();
        }

        public override void Update()
        {
            
        }

        public void Toggle()
        {
            this.isOn = !this.isOn;

            if (this.isOn)
            {
                this.animation = this.onAnimation;
                this.SetAnimation(this.animation);
                this.animation.Start();
            }
            else
            {
                this.animation = this.offAnimation;
                this.SetAnimation(this.animation);
                this.animation.Start();
            }
        }

        public void TurnOn()
        {
            if (!this.isOn)
                this.Toggle();
        }

        public void TurnOff()
        {
            if (this.isOn)
                this.Toggle();
        }

        public bool IsOn()
        {
            return this.isOn;
        }

        public void Notify()
        {
            this.Toggle();
        }
    }
}
