﻿using Merlin2d.Game;
using Merlin2d.Game.Actors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.Actors
{
    public class PowerSource : AbstractActor, ISwitchable, IObservable
    {
        private Animation animation;
        private Animation onAnimation;
        private Animation offAnimation;

        private bool isOn = false;

        private List<IObserver> observers;

        public PowerSource(int x, int y)
        {
            this.onAnimation = new Animation("resources/source_on.png", 56, 60);
            this.offAnimation = new Animation("resources/source_off.png", 56, 60);

            this.UpdateAnimation(this.offAnimation);
            this.SetPosition(x, y);

            this.observers = new List<IObserver>();
        }

        private void UpdateAnimation(Animation animation)
        {
            this.animation = animation;
            this.SetAnimation(this.animation);
            this.animation.Start();
        }

        public override void Update()
        {
            if (Input.GetInstance().IsKeyPressed(Input.Key.E))
                this.Toggle();
        }

        public void Toggle()
        {
            this.isOn = !this.isOn;

            if (this.isOn)
            {
                this.animation = this.onAnimation;
                this.SetAnimation(this.animation);
                this.animation.Start();
            }
            else
            {
                this.animation = this.offAnimation;
                this.SetAnimation(this.animation);
                this.animation.Start();
            }

            foreach (IObserver observer in this.observers)
                observer.Notify();
        }

        public void TurnOn()
        {
            if (!this.isOn)
                this.Toggle();
        }

        public void TurnOff()
        {
            if (this.isOn)
                this.Toggle();
        }

        public bool IsOn()
        {
            return this.isOn;
        }

        public void Subscribe(IObserver observer)
        {
            this.observers.Add(observer);
        }

        public void Unsubscribe(IObserver observer)
        {
            if (this.observers.Contains(observer))
                this.observers.Remove(observer);
        }
    }
}
