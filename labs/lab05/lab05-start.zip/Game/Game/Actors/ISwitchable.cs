﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.Actors
{
    public interface ISwitchable
    {
        public void Toggle();
        public void TurnOn();
        public void TurnOff();
        public bool IsOn();
    }
}
