﻿using Merlin2d.Game.Actors;

namespace GameCore.Actors
{
    public interface IUsable
    {
        void Use(IActor actor);
    }
}
