﻿using GameCore.Actors;
using GameCore.Commands;
using GameCore.Factories;
using Merlin2d.Game;
using Merlin2d.Game.Actors;
using System.Runtime.InteropServices;

namespace GameCore
{
    internal class Program
    {
        static void Main(string[] args)
        {
            GameContainer container = new GameContainer("Game window", 500, 500);

            container.SetMap("resources/maps/map01.tmx");
            container.GetWorld().SetPhysics(new Gravity());
            container.GetWorld().SetFactory(new ActorFactory());

            container.GetWorld().AddInitAction(world =>
            {
                IActor actor = world.GetActors().Find(x => x.GetName() == "Merlin");
                world.CenterOn(actor);
            });

            container.Run();
        }
    }
}