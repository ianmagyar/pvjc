﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using MyGame.Actors;
using MyGame.Strategies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Items
{
    public class Star : AbstractActor
    {
        public Star(string name, ContentManager content, Vector2 position) : base(name)
        {
            SetTexture(content.Load<Texture2D>("star"));
            SetPosition((int)position.X, (int)position.Y);
        }

        public override void Update(GameTime gameTime)
        {
            IActor player = world.GetActor("Player");
            if (player != null && IntersectsWithActor(player))
            {
                (player as IMovable).SetSpeedStrategy(new ModifiedSpeedStrategy(2));
                RemoveFromWorld();
            }
        }
    }
}
