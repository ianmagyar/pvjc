﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MyGame.Actors;
using MyGame.Factories;
using MyGame.Utils;
using MyGame.Worlds;
using System;

namespace MyGame
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        private SpriteFont healthFont;
                
        private Bomb bomb;
        private LightBulb bulb;
        private PowerSwitch powerSwitch;

        private LightBulb bulb2;
        private LightBulb bulb3;

        private Player player;
        private GameWorld world;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;

            TargetElapsedTime = TimeSpan.FromSeconds(1d / 30d);
            world = new GameWorld(480, 800);
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        protected override void LoadContent()
        {
            ActorFactory aFactory = new ActorFactory(Content);
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            healthFont = Content.Load<SpriteFont>("Health");

            // TODO: use this.Content to load your game content here
            //bomb = (Bomb)aFactory.Create("Bomb", "bomb", 200, 200);
            powerSwitch = (PowerSwitch)aFactory.Create("PowerSwitch", "switch", 100, 300);
            bulb = (LightBulb)aFactory.Create("LightBulb", "lightbulb1", 400, 100);
            bulb.AddPowerSwitch(powerSwitch);
            powerSwitch.Toggle();
            bulb2 = (LightBulb)aFactory.Create("LightBulb", "lightbulb2", 500, 100);
            bulb2.AddPowerSwitch(powerSwitch);
            bulb3 = (CrackedLightBulb)aFactory.Create("CrackedLightBulb", "lightbulb3", 550, 100);
            bulb3.AddPowerSwitch(powerSwitch);

            //player = (Player)aFactory.Create("Player", "Player", 250, 250);

            world.AddActor(aFactory.Create("Bomb", "bomb", 200, 200));
            world.AddActor(powerSwitch);
            world.AddActor(bulb);
            world.AddActor(bulb2);
            world.AddActor(bulb3);
            world.AddActor(aFactory.Create("Player", "Player", 250, 400));
            world.AddActor(aFactory.Create("Star", "star", 100, 430));
            world.AddActor(aFactory.Create("Spike", "spike1", 300, 464));
            world.AddActor(aFactory.Create("Spike", "spike2", 310, 464));
            world.AddActor(aFactory.Create("Spike", "spike3", 320, 464));
            world.AddActor(aFactory.Create("Spike", "spike4", 330, 464));
            world.AddActor(aFactory.Create("Spike", "spike5", 340, 464));
        }

        protected override void Update(GameTime gameTime)
        {
            KeyChecker.GetState();
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();


            // TODO: Add your update logic here
            world.Update(gameTime);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            world.Draw(_spriteBatch);

            Player player = world.GetActor("Player") as Player;
            if (player != null)
            {
                _spriteBatch.Begin();
                _spriteBatch.DrawString(healthFont, "Health: " + player.GetHealth(), new Vector2(20, 20), Color.Black);
                _spriteBatch.End();
            }

            base.Draw(gameTime);
        }
    }
}