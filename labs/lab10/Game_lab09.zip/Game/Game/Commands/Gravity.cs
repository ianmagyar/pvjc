﻿using MyGame.Actors;
using MyGame.Worlds;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Commands
{
    // Task 2.2
    public class Gravity : IPhysics
    {
        private IWorld world;
        private Fall<IActor> fall = new Fall<IActor>();

        public void Execute()
        {
            List<IActor> actors = this.world.GetActors();

            foreach (IActor actor in actors)
            {
                if (actor.IsAffectedByPhysics())
                {
                    fall.Execute(actor);
                }
            }
        }

        public void SetTarget(ICharacter target)
        {
            
        }

        public void SetWorld(IWorld world)
        {
            this.world = world;
        }
    }
}
