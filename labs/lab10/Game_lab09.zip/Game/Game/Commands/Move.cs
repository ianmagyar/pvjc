﻿using MyGame.Actors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Commands
{
    // Update in Task 3
    public class Move : ICommand
    {
        private IMovable actor;
        private int dx;
        private int dy;

        public Move(IMovable movable, int dx, int dy)
        {
            if (!(movable is AbstractActor))
                throw new ArgumentException("Cannot move object, it is not AbstractCharacter");

            this.actor = movable;
            this.dx = dx;
            this.dy = dy;
        }

        public void Execute()
        {
            double speed = actor.GetSpeed();

            // not completely correct, if you want to do it in earnest, you'll have to have two
            // representations of position: one with Vector2, one with double X and Y and switch between them
            (actor as AbstractActor).SetPosition(
                (actor as AbstractActor).GetX() + (int)(speed * dx),
                (actor as AbstractActor).GetY() + (int)(speed * dy)
            );
        }

        public void SetTarget(ICharacter target)
        {
            
        }
    }
}
