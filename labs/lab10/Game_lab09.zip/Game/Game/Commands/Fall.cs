﻿using MyGame.Actors;

namespace MyGame.Commands
{
    // Task 2.2
    public class Fall<T> : IAction<T> where T : IActor
    {
        private int step;
        private int dx;
        private int dy;

        public Fall()
        {
            this.step = 2;
            this.dx = 0;
            this.dy = 1;
        }

        public void Execute(T actor)
        {
            int oldX = actor.GetX();
            int oldY = actor.GetY();
            int newX = actor.GetX() + step * dx;
            int newY = actor.GetY() + step * dy;

            actor.SetPosition(newX, newY);

            if (newY > (actor.GetWorld().GetHeight() - actor.GetHeight()))
                actor.SetPosition(oldX, oldY);
        }
    }
}
