﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using MyGame.Actors;
using MyGame.Items;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Factories
{
    public class ActorFactory : IFactory
    {
        private ContentManager content;

        public ActorFactory(ContentManager content)
        {
            this.content = content;
        }

        public IActor Create(String actorType, String actorName, int x, int y)
        {
            if (actorType == "Player")
            {
                return new Player(actorName, content, new Vector2(x, y));
            }
            else if (actorType == "Bomb")
            {
                return new Bomb(actorName, content, new Vector2(x, y));
            }
            else if (actorType == "PowerSwitch")
            {
                return new PowerSwitch(actorName, content, new Vector2(x, y));
            }
            else if (actorType == "LightBulb")
            {
                return new LightBulb(actorName, content, new Vector2(x, y), null);
            }
            else if (actorType == "CrackedLightBulb")
            {
                return new CrackedLightBulb(actorName, content, new Vector2(x, y), null, 5);
            }
            else if (actorType == "Star")
            {
                return new Star(actorName, content, new Vector2(x, y));
            }
            else if (actorType == "Spike")
            {
                return new Spike(actorName, content, new Vector2(x, y));
            }
            else
            {
                return null;
            }
        }
    }
}
