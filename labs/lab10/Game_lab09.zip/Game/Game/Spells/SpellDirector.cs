﻿using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using MyGame.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Spells
{
    public class SpellDirector : ISpellDirector
    {
        private Dictionary<string, int> effectCosts;
        private Dictionary<string, SpellInfo> spells;

        private ISpellBuilder projectileBuilder;
        private ISpellBuilder selfCastBuilder;

        private IWizard wizard;
        private ContentManager content;

        public SpellDirector(IWizard wizard, ContentManager content)
        {
            effectCosts = new Dictionary<string, int>()
            {
                {"DoT-3x5", 15},
                {"DoT-3x10", 30},
                {"HoT-3x10", 30},
                {"HoT-3x5", 30},
                {"Heal-10", 5},
                {"Heal-20", 10},
                {"SpeedChange-10", 5}
            };
            spells = new Dictionary<string, SpellInfo>()
            {
                {"PSpell1", new SpellInfo(){Name="PSpell1", SpellType=SpellType.ProjectileSpell, EffectNames=new List<string>(){"DoT-3x10", "SpeedChange-10"}, TextureName="ball", TextureHeight=8, TextureWidth=8 } },
                {"SSpell1", new SpellInfo(){Name="SSpell1", SpellType=SpellType.SelfCastSpell, EffectNames=new List<string>(){"Heal-20"}} }
            };
            projectileBuilder = new ProjectileSpellBuilder();
            selfCastBuilder = new SelfCastSpellBuilder();

            this.wizard = wizard;
            this.content = content;
        }

        public ISpell Build(string spellName)
        {
            SpellInfo spellInfo = spells[spellName];

            ISpellBuilder builder;
            if (spellInfo.SpellType == SpellType.ProjectileSpell)
            {
                builder = projectileBuilder;
                builder.SetTexture(content.Load<Texture2D>(spellInfo.TextureName));
            }
            else
            {
                builder = selfCastBuilder;
            }

            int totalCost = 0;
            foreach (string effect in spellInfo.EffectNames)
            {
                builder = builder.AddEffect(effect);
                totalCost += effectCosts[effect];
            }
            builder.SetSpellCost(totalCost);

            return builder.CreateSpell(wizard);
        }
    }
}
