﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MyGame.Actors;
using MyGame.Commands;
using MyGame.Strategies;
using System;
using System.Collections.Generic;

namespace MyGame.Spells
{
    public class ProjectileSpell : AbstractActor, IMovable, ISpell
    {
        private IWizard wizard;
        private IEnumerable<ICommand> effects;
        private int cost;
        private ICommand move;
        private bool used = false;

        public ProjectileSpell(IWizard wizard, IEnumerable<ICommand> effects, int cost, Texture2D texture) : base()
        {
            this.wizard = wizard;
            this.effects = effects;
            this.cost = cost;

            SetTexture(texture);
        }

        public ISpell AddEffect(ICommand effect)
        {
            (effects as List<ICommand>).Add(effect);
            return this;
        }

        public void AddEffects(IEnumerable<ICommand> effects)
        {
            this.effects = effects;
        }

        public void ApplyEffects(ICharacter target)
        {
            foreach (ICommand effect in effects)
            {
                effect.SetTarget(target);
                target.AddEffect(effect);
            }
        }

        public double GetBaseSpeed()
        {
            return 1;
        }

        public int GetCost()
        {
            return cost;
        }

        public double GetSpeed()
        {
            return 1;
        }

        public void SetSpeedStrategy(ISpeedStrategy strategy)
        {
            
        }

        public void SetDirection(bool movingRight)
        {
            if (movingRight)
                move = new Move(this, 1, 0);
            else
                move = new Move(this, -1, 0);
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            if (move != null)
                move.Execute();

            if (used)
                return;

            foreach (IActor actor in world.GetActors())
            {
                if (IntersectsWithActor(actor))
                {
                    if (actor is ICharacter)
                    {
                        ApplyEffects((actor as ICharacter));
                        used = true;
                        RemoveFromWorld();
                    }
                }
            }
        }
    }
}
