﻿using System.Collections.Generic;

namespace MyGame.Spells
{
    public class SpellInfo
    {
        public string Name { get; set; }
        public SpellType SpellType { get; set; }
        public IEnumerable<string> EffectNames { get; set; }
        public string TextureName { get; set; }
        public int TextureWidth { get; set; }
        public int TextureHeight { get; set; }
    }
}
