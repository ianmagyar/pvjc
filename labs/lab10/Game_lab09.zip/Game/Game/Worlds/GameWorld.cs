﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MyGame.Actors;
using MyGame.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Worlds
{
    public class GameWorld : IWorld
    {
        private int height;
        private int width;
        private List<IActor> actorsToBeAdded;
        private List<IActor> actors;
        private IPhysics gamePhysics;

        // Task 1.2
        public GameWorld(int height, int width)
        {
            this.height = height;
            this.width = width;
            actors = new List<IActor>();
            actorsToBeAdded = new List<IActor>();

            // Task 2.3
            gamePhysics = new Gravity();
            gamePhysics.SetWorld(this);
        }

        public void AddActor(IActor actor)
        {
            actorsToBeAdded.Add(actor);
        }

        public void RemoveActor(IActor actor)
        {
            actor.RemoveFromWorld();
        }

        public List<IActor> GetActors()
        {
            return actors;
        }

        public IActor? GetActor(string name)
        {
            return actors.Find(a => a.GetName().Equals(name));
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            actors.ForEach(actor => actor.Draw(spriteBatch));
        }

        public void Update(GameTime gameTime)
        {
            actorsToBeAdded.ForEach(actor =>
            {
                actors.Add(actor);
                actor.OnAddedToWorld(this);
            });
            actorsToBeAdded.Clear();

            // Task 2.3
            if (gamePhysics != null)
            {
                gamePhysics.Execute();
            }

            actors.ForEach(actor => actor.Update(gameTime));
            actors.RemoveAll(actor => actor.RemovedFromWorld());
        }

        // Task 1.2
        public int GetHeight()
        {
            return this.height;
        }

        public int GetWidth()
        {
            return this.width;
        }
    }
}
