﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MyGame.Actors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Worlds
{
    // Task 1.2
    public interface IWorld
    {
        void AddActor(IActor actor);

        void RemoveActor(IActor actor);

        List<IActor> GetActors();

        IActor? GetActor(string name);

        void Draw(SpriteBatch spriteBatch);

        void Update(GameTime gameTime);

        int GetHeight();

        int GetWidth();
    }
}
