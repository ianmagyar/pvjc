﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyGame.Actors
{
    public abstract class AbstractAnimatedActor : AbstractActor
    {
        // in Task 3
        protected enum ActorOrientation
        {
            FacingLeft,
            FacingRight
        }

        protected int rows;
        protected int columns;
        protected int width;
        protected int height;
        protected int currentFrame;
        protected int totalFrames;
        protected ActorOrientation orientation;

        protected AbstractAnimatedActor(string name, Texture2D texture, int rows, int columns) : base(name)
        {
            SetTexture(texture);
            this.rows = rows;
            this.columns = columns;
            width = texture.Width / columns;
            height = texture.Height / rows;
            currentFrame = 0;
            totalFrames = this.rows * this.columns;
            // facing right by default - Task 3
            orientation = ActorOrientation.FacingRight;
        }

        public override int GetWidth()
        {
            return this.width;
        }

        public override int GetHeight()
        {
            return this.height;
        }
        public override void Draw(SpriteBatch spriteBatch)
        {
            int row = currentFrame / columns;
            int col = currentFrame % columns;

            Rectangle sourceRectangle = new Rectangle(width * col, height * row, width, height);
            Rectangle destinationRectangle = new Rectangle((int)GetX(), (int)GetY(), width, height);

            spriteBatch.Begin();
            spriteBatch.Draw(texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
