﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MyGame.Commands;
using MyGame.Spells;
using MyGame.Strategies;
using MyGame.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace MyGame.Actors
{
    // change in Task 4
    public class Player : AbstractCharacter, IWizard
    {
        private Move moveUp;
        private Move moveDown;
        private Move moveLeft;
        private Move moveRight;

        // Task 3 - use enumeration for direction
        private bool isMoving;

        private int jumpHeight;
        private int jumpStart;
        private bool isJumping;

        private int mana;
        private SpellDirector director;

        public Player(string name, ContentManager content, Vector2 position) : base(name, content.Load<Texture2D>("player"), 1, 9, 2)
        {
            SetPosition((int)position.X, (int)position.Y);

            moveUp = new Move(this, 0, -1);
            moveDown = new Move(this, 0, 1);
            moveLeft = new Move(this, -1, 0);
            moveRight = new Move(this, 1, 0);
            isMoving = false;

            jumpHeight = 40;

            SetPhysics(true);

            // Task 4
            SetSpeedStrategy(new NormalSpeedStrategy());
            SetSpeedStrategy(new ModifiedSpeedStrategy(0.5));

            this.mana = 100;
            this.director = new SpellDirector(this, content);
        }

        public void UpdatePosition(int dx, int dy)
        {
            position.X += dx;
            position.Y += dy;
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            int row = currentFrame / columns;
            int col = currentFrame % columns;

            Rectangle sourceRectangle = new Rectangle(width * col, height * row, width, height);
            Rectangle destinationRectangle = new Rectangle((int)position.X, (int)position.Y, width, height);

            SpriteEffects effect = orientation == ActorOrientation.FacingLeft ? SpriteEffects.FlipHorizontally : SpriteEffects.None;

            spriteBatch.Begin();
            spriteBatch.Draw(texture, destinationRectangle, sourceRectangle, Color.White, 0f, new Vector2(0, 0), effect, 0f);
            spriteBatch.End();
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            isMoving = false;
            //if (KeyChecker.IsPressed(Keys.Up))
            //{
            //    moveUp.Execute();
            //    isMoving = true;
            //}
            //if (KeyChecker.IsPressed(Keys.Down))
            //{
            //    moveDown.Execute();
            //    isMoving = true;
            //}
            if (KeyChecker.IsPressed(Keys.Left))
            {
                orientation = ActorOrientation.FacingLeft;
                moveLeft.Execute();
                isMoving = true;
            }
            if (KeyChecker.IsPressed(Keys.Right))
            {
                orientation = ActorOrientation.FacingRight;
                moveRight.Execute();
                isMoving = true;
            }
            // Task 3
            if (KeyChecker.HasBeenPressed(Keys.Space) && !isJumping)
            {
                isJumping = true;
                jumpStart = GetY();
                SetPhysics(false);
            }
            if (KeyChecker.HasBeenPressed(Keys.D1))
            {
                Cast(director.Build("PSpell1"));
            }
            if (KeyChecker.HasBeenPressed(Keys.D2))
            {
                Cast(director.Build("SSpell1"));
            }

            if (isJumping)
            {
                foreach (IActor actor in world.GetActors())
                {
                    if (actor != this && IntersectsWithActor(actor))
                    {
                        isJumping = false;
                        SetPhysics(true);
                    }
                }

                if (jumpStart - GetY() < jumpHeight)
                {
                    moveUp.Execute();
                }
                else
                {
                    isJumping = false;
                    SetPhysics(true);
                }
            }

            if (isMoving)
            {
                currentFrame++;
                if (currentFrame == totalFrames)
                    currentFrame = 0;
            }
            else
            {
                currentFrame = 0;
            }
        }

        public void ChangeMana(int delta)
        {
            mana += delta;
            if (mana > 100)
                mana = 100;
            if (mana < 0)
                mana = 0;
        }

        public int GetMana()
        {
            return mana;
        }

        public void Cast(ISpell spell)
        {
            if (mana < spell.GetCost())
                return;

            if (spell is ProjectileSpell)
            {
                // add to world with
                ProjectileSpell pSpell = (spell as ProjectileSpell);
                GetWorld().AddActor(pSpell);

                int x = GetX();
                if (orientation == ActorOrientation.FacingRight)
                {
                    x += GetWidth() + 10;
                    pSpell.SetDirection(true);
                }
                else
                {
                    x -= 10;
                    pSpell.SetDirection(false);
                }

                pSpell.SetPosition(x, GetY() + GetHeight() / 2);
                
            }
            else if (spell is SelfCastSpell)
            {
                spell.ApplyEffects(this);
            }

            ChangeMana(-spell.GetCost());
        }
    }
}
