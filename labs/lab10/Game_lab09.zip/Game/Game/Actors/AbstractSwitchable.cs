﻿using Microsoft.Xna.Framework.Graphics;

namespace MyGame.Actors
{
    public abstract class AbstractSwitchable : AbstractActor, ISwitchable
    {
        protected Texture2D offTexture;
        protected Texture2D onTexture;
        protected bool isOn;

        protected AbstractSwitchable(string name) : base(name)
        {

        }

        public virtual void Toggle()
        {
            isOn = !isOn;
            if (isOn)
                SetTexture(onTexture);
            else
                SetTexture(offTexture);
        }

        public virtual void TurnOn()
        {
            if (!isOn)
                Toggle();
        }
        
        public void TurnOff()
        {
            if (isOn)
                Toggle();
        }

        public bool IsOn()
        {
            return isOn;
        }
    }
}
