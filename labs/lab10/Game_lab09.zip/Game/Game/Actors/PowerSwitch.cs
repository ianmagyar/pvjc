﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MyGame.Utils;
using System.Collections.Generic;

namespace MyGame.Actors
{
    public class PowerSwitch : AbstractSwitchable, IObservable
    {

        private List<IObserver> observers;

        public PowerSwitch(string name, ContentManager content, Vector2 position) : base(name)
        {
            offTexture = content.Load<Texture2D>("switch_off");
            onTexture = content.Load<Texture2D>("switch_on");
            SetTexture(offTexture);

            SetPosition((int)position.X, (int)position.Y);
            isOn = false;

            observers = new List<IObserver>();
        }

        public override void Toggle()
        {
            base.Toggle();

            foreach (IObserver observer in observers)
                observer.Notify(this);
        }

        public void Subscribe(IObserver observer)
        {
            observers.Add(observer);
        }

        public void Unsubscribe(IObserver observer)
        {
            if (observers.Contains(observer))
                observers.Remove(observer);
        }

        public override void Update(GameTime gameTime)
        {
            IActor player = this.world.GetActor("Player");
            if (KeyChecker.HasBeenPressed(Keys.E))
                if (player != null && this.IntersectsWithActor(player))
                    Toggle();
        }
    }
}
