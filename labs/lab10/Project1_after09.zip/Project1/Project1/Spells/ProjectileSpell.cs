﻿using Project1.Actors;
using Project1.Commands;
using Project1.Strategies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Spells
{
    public class ProjectileSpell : AbstractActor, IMovable, ISpell
    {
        private IWizard caster;
        private IEnumerable<ICommand> effects;

        public ProjectileSpell(IWizard caster, IEnumerable<ICommand> effects)
        {
            this.caster = caster;
            this.effects = effects;
        }

        public ISpell AddEffect(ICommand effect)
        {
            effects.Append(effect);
            return this;
        }

        public void AddEffects(IEnumerable<ICommand> effects)
        {
            foreach (ICommand effect in effects)
            {
                this.effects.Append(effect);
            }
        }

        public void ApplyEffects(ICharacter target)
        {
            foreach (ICommand effect in effects)
            {
                target.AddEffect(effect);
            }
        }

        public double GetBaseSpeed()
        {
            return 3;
        }

        public int GetCost()
        {
            return 10;
        }

        public double GetSpeed()
        {
            return GetBaseSpeed();
        }

        public void SetSpeedStrategy(ISpeedStrategy strategy)
        {
            
        }
    }
}
