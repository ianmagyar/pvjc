﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Strategies
{
    public class ModifiedSpeedStrategy : ISpeedStrategy
    {
        public ModifiedSpeedStrategy() { }

        public double GetSpeed(double speed)
        {
            return 2.0 * speed;
        }
    }
}
