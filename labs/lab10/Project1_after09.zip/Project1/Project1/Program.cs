﻿
using var game = new Project1.Game1();
game.Run();
