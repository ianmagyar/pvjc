﻿using Project1.Actors;
using Project1.Strategies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Commands
{
    public class SpeedChange : ICommand
    {
        private int duration;
        private int counter;
        private bool active = false;
        private bool used = false;
        private int cost;

        private ICharacter target;

        private ISpeedStrategy original;
        private ISpeedStrategy changed;

        public SpeedChange(int duration, int cost)
        {
            this.duration = duration;
            this.changed = new ModifiedSpeedStrategy();
            this.cost = cost;
        }

        public void SetTarget(ICharacter target)
        {
            this.target = target;
            original = (target as AbstractCharacter).GetSpeedStrategy();
        }

        public void Execute()
        {
            if (target == null)
                return;

            if (!active && !used)
            {
                target.SetSpeedStrategy(changed);
                active = true;
                used = true;
            }

            if (active)
            {
                counter++;
                if (counter == duration * 30)
                {
                    target.SetSpeedStrategy(original);
                    active = false;
                }
            }
        }
    }
}
