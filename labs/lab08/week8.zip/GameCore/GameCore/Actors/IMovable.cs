﻿namespace GameCore.Actors
{
    public interface IMovable
    {
    }
}
