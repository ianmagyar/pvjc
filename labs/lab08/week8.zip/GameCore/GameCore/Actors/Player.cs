﻿using GameCore.Commands;
using Merlin2d.Game;
using Merlin2d.Game.Actions;

namespace GameCore.Actors
{
    public class Player : AbstractActor, IMovable
    {
        private Animation animation;

        private int speed;
        private ICommand lastMove;
        private ICommand moveUp;
        private ICommand moveDown;
        private ICommand moveRight;
        private ICommand moveLeft;

        public Player(int x, int y, int speed)
        {
            this.SetPosition(x, y);

            animation = new Animation("resources/sprites/player.png", 28, 47);
            this.SetAnimation(animation);
            this.GetAnimation().Start();

            this.speed = speed;
            this.moveUp = new Move(this, speed, 0, -1);
            this.moveDown = new Move(this, speed, 0, 1);
            this.moveRight = new Move(this, speed, 1, 0);
            this.moveLeft = new Move(this, speed, -1, 0);
            this.lastMove = moveRight;
        }
        public override void Update()
        {
            if (Input.GetInstance().IsKeyDown(Input.Key.UP))
            {
                animation.Start();
                this.moveUp.Execute();
            }
            else if (Input.GetInstance().IsKeyDown(Input.Key.DOWN))
            {
                animation.Start();
                this.moveDown.Execute();
            }
            else if (Input.GetInstance().IsKeyDown(Input.Key.RIGHT))
            {
                if (this.lastMove == moveLeft)
                    animation.FlipAnimation();
                animation.Start();
                this.moveRight.Execute();
                this.lastMove = moveRight;
            }
            else if (Input.GetInstance().IsKeyDown(Input.Key.LEFT))
            {
                if (this.lastMove == moveRight)
                    animation.FlipAnimation();
                animation.Start();
                this.moveLeft.Execute();
                this.lastMove = moveLeft;
            }
            else
            {
                animation.Stop();
            }
        }
    }
}
