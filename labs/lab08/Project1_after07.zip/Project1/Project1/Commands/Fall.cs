﻿using Project1.Actors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Commands
{
    public class Fall<T> : IAction<T> where T : IActor
    {
        public Fall()
        {

        }

        public void Execute(T value)
        {
            if (value.GetY() < value.GetWorld().GetHeight() - value.GetHeight())
            {
                value.UpdatePosition(0, 2);
            }            
        }
    }
}
