﻿using Project1.Actors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Commands
{
    public class Move : ICommand
    {
        private int step;
        private int dx;
        private int dy;
        private IMovable movable;

        public Move(IMovable movable, int step, int dx, int dy)
        {
            if (!(movable is Player))
            {
                throw new ArgumentException("Can only move Player");
            }
            this.movable = movable;
            this.step = step;
            this.dx = dx;
            this.dy = dy;
        }

        public void Execute()
        {
            (movable as Player).UpdatePosition(dx * step, dy * step);
        }
    }
}
