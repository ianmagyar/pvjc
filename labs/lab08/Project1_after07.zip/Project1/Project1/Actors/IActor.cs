﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project1.Worlds;

namespace Project1.Actors
{
    public interface IActor
    {
        string GetName();
        void SetName(string name);
        int GetX();
        int GetY();
        int GetHeight();
        int GetWidth();
        void SetPosition(int posX, int posY);
        void OnAddedToWorld(IWorld world);
        IWorld GetWorld();
        Texture2D GetTexture();
        void SetTexture(Texture2D texture);
        bool IntersectsWithActor(IActor other);
        void SetPhysics(bool isPhysicsEnabled);
        bool IsAffectedByPhysics();
        void RemoveFromWorld();
        bool RemovedFromWorld();
        void Update(GameTime gameTime);
        void Draw(SpriteBatch spriteBatch);
        void UpdatePosition(int dx, int dy);
    }
}
