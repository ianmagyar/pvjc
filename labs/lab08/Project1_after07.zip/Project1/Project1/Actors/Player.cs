﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Project1.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Project1.Actors
{
    public class Player : AbstractAnimatedActor, IMovable
    {
        private int speed;
        private Commands.ICommand moveUp;
        private Commands.ICommand moveDown;
        private Commands.ICommand moveLeft;
        private Commands.ICommand moveRight;
        private bool movingLeft;

        private float timer;
        private const float TIMER = 0.1f;

        private int jumpStart;
        private int jumpHeight;
        private bool isJumping;

        public Player(string name, ContentManager content, Vector2 position) : base(name, content.Load<Texture2D>("player"), 1, 9)
        {
            this.position = position;

            timer = TIMER;

            speed = 2;
            moveUp = new Move(this, speed, 0, -1);
            moveDown = new Move(this, speed, 0, 1);
            moveLeft = new Move(this, speed, -1, 0);
            moveRight = new Move(this, speed, 1, 0);
            movingLeft = false;
            jumpHeight = 30;

            SetPhysics(true);
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            int row = currentFrame / columns;
            int col = currentFrame % columns;

            Rectangle sourceRectangle = new Rectangle(width * col, height * row, width, height);
            Rectangle destinationRectangle = new Rectangle((int)position.X, (int)position.Y, width, height);

            // TODO: draw bomb using spriteBatch
            spriteBatch.Begin();
            if (movingLeft)
            {
                spriteBatch.Draw(texture, destinationRectangle, sourceRectangle, Color.White, 0f, new Vector2(0, 0), SpriteEffects.FlipHorizontally, 0f);
            }
            else
            {
                spriteBatch.Draw(texture, destinationRectangle, sourceRectangle, Color.White);
            }
            spriteBatch.End();
        }

        public override void Update(GameTime gameTime)
        {
            bool isMoving = false;
            if (!isJumping && KeyChecker.HasBeenPressed(Keys.Space))
            {
                isMoving = true;
                isJumping = true;
                jumpStart = GetY();
                SetPhysics(false);
            }
            if (isJumping)
            {
                if (GetY() >= jumpStart - jumpHeight)
                {
                    moveUp.Execute();
                }
                else
                {
                    isJumping = false;
                    isMoving = false;
                    SetPhysics(true);
                }
            }
            if (KeyChecker.IsPressed(Keys.Up))
            {
                isMoving = true;
                moveUp.Execute();
            }
            if (KeyChecker.IsPressed(Keys.Down))
            {
                isMoving = true;
                moveDown.Execute();
            }
            if (KeyChecker.IsPressed(Keys.Left))
            {
                isMoving = true;
                movingLeft = true;
                moveLeft.Execute();
            }
            if (KeyChecker.IsPressed(Keys.Right))
            {
                isMoving = true;
                movingLeft = false;
                moveRight.Execute();
            }
            timer -= (float)gameTime.ElapsedGameTime.TotalSeconds;
            if (timer < 0)
            {
                timer = TIMER;

                if (isMoving)
                {
                    currentFrame++;
                    if (currentFrame == totalFrames)
                    {
                        currentFrame = 0;
                    }
                }
                else
                {
                    currentFrame = 0;
                }
            }
        }
    }
}
