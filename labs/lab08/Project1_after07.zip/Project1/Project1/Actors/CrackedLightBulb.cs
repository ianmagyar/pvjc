﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Actors
{
    public class CrackedLightBulb : LightBulb
    {
        private int maxUses;
        private int uses;

        public CrackedLightBulb(string name, ContentManager contentManager, Vector2 position, PowerSwitch powerSwitch, int maxUses) : base(name, contentManager, position, powerSwitch)
        {
            this.maxUses = maxUses;
            uses = 0;
        }

        public override void TurnOn()
        {
            uses++;
            if (uses <= maxUses)
            {
                base.TurnOn();
            }
        }
    }
}
