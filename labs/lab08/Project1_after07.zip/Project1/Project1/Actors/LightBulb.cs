﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Actors
{
    public class LightBulb : AbstractSwitchable, IObserver
    {
        private PowerSwitch powerSwitch;

        public LightBulb(string name, ContentManager contentManager, Vector2 position, PowerSwitch powerSwitch) : base(name)
        {
            this.position = position;
            onTexture = contentManager.Load<Texture2D>("bulb_on");
            offTexture = contentManager.Load<Texture2D>("bulb_off");

            ConnectToSwitch(powerSwitch);
        }

        public void ConnectToSwitch(PowerSwitch powerSwitch)
        {
            this.powerSwitch = powerSwitch;
            if (powerSwitch == null)
            {
                texture = offTexture;
                turnedOn = false;
            }
            else
            {
                powerSwitch.Subscribe(this);
                turnedOn = powerSwitch.IsOn();
                texture = turnedOn ? onTexture : offTexture;
            }
        }

        /*public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(texture, position, Color.White);
            spriteBatch.End();
        }*/

        public void Notify(IObservable observable)
        {
            if ((observable as PowerSwitch).IsOn() != turnedOn)
            {
                Toggle();
            }
        }
    }
}
