﻿using Project1.Actors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Commands
{
    public class Move : ICommand
    {
        private double dx;
        private double dy;
        private IMovable movable;

        public Move(IMovable movable, double dx, double dy)
        {
            /*if (!(movable is ICharacter))
            {
                throw new ArgumentException("Can only move Player");
            }*/
            this.movable = movable;
            this.dx = dx;
            this.dy = dy;
        }

        public void Execute()
        {
            double speed = movable.GetSpeed();

            AbstractActor aActor = (movable as AbstractActor);
            double newX = aActor.GetX() + (speed * dx);
            double newY = aActor.GetY() + (speed * dy);
            if (!aActor.GetWorld().IntersectsWithWall(aActor))
                aActor.SetPosition((int)newX, (int)newY);
        }
    }
}
