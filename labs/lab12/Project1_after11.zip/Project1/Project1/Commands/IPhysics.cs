﻿using Project1.Worlds;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Commands
{
    public interface IPhysics : ICommand
    {
        void SetWorld(IWorld world);
    }
}
