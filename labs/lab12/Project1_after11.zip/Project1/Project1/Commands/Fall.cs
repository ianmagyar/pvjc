﻿using Project1.Actors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Commands
{
    public class Fall<T> : IAction<T> where T : IActor
    {
        public Fall()
        {

        }

        public void Execute(T value)
        {
            double oldX = value.GetX();
            double oldY = value.GetY();
            double newX = value.GetX();
            double newY = value.GetY() + 2;

            value.SetPosition((int)newX, (int)newY);

            if (newY > (value.GetWorld().GetHeight() - value.GetHeight()) || value.GetWorld().IntersectsWithWall(value))
                value.SetPosition((int)oldX, (int)oldY);
        }
    }
}
