﻿using Project1.Actors;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Commands
{
    public class Heal : ICommand
    {
        private int healthChange;
        private ICharacter target;
        private bool used = false;
        private int cost;

        public Heal(int change, int cost)
        {
            healthChange = change;
            this.cost = cost;
        }

        public void SetTarget(ICharacter target)
        {
            this.target = target;
        }

        public void Execute()
        {
            if (!used)
            {
                target.ChangeHealth(healthChange);
                used = true;
            }
        }
    }
}
