﻿using Project1.Actors;
using Project1.Worlds;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Commands
{
    public class Gravity : IPhysics
    {
        private IWorld world;
        private IAction<IActor> fall;

        public Gravity()
        {
            fall = new Fall<IActor>();
        }

        public void Execute()
        {
            if (world == null)
            {
                return;
            }

            foreach (IActor actor in world.GetActors())
            {
                if (actor.IsAffectedByPhysics())
                {
                    fall.Execute(actor);
                }
            }
        }

        public void SetWorld(IWorld world)
        {
            this.world = world;
        }
    }
}
