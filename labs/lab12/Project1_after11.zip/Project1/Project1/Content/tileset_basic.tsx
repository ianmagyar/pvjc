<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tileset_basic" tilewidth="16" tileheight="16" tilecount="960" columns="32">
 <image source="tileset_basic.png" width="512" height="480"/>
</tileset>
