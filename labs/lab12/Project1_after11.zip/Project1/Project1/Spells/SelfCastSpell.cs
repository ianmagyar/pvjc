﻿using Project1.Actors;
using Project1.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Spells
{
    public class SelfCastSpell : ISpell
    {
        private IWizard caster;
        private IEnumerable<ICommand> effects;
        private int cost;

        public SelfCastSpell(IWizard caster, IEnumerable<ICommand> effects, int cost)
        {
            this.caster = caster;
            this.effects = effects;
            this.cost = cost;
        }

        public ISpell AddEffect(ICommand effect)
        {
            effects.Append(effect);
            return this;
        }

        public void AddEffects(IEnumerable<ICommand> effects)
        {
            foreach (ICommand effect in effects)
            {
                this.effects.Append(effect);
            }
        }

        public void ApplyEffects(ICharacter target)
        {
            foreach (ICommand effect in effects)
            {
                target.AddEffect(effect);
            }
        }

        public int GetCost()
        {
            return cost;
        }
    }
}
