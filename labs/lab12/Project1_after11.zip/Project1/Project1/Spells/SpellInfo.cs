﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Spells
{
    public class SpellInfo
    {
        public string Name { get; set; }
        public SpellType SpellType { get; set; }
        public IEnumerable<string> EffectNames { get; set; }
        public string TextureName { get; set; }
        public int TextureWidth { get; set; }
        public int TextureHeight { get; set; }

        public static explicit operator SpellInfo(string data)
        {
            string[] values = data.Split(';');

            return new SpellInfo
            {
                Name = values[0],
                SpellType = values[1] == "projectile" ? SpellType.ProjectileSpell : SpellType.SelfCastSpell,
                TextureName = values[2],
                TextureWidth = int.Parse(values[3]),
                TextureHeight = int.Parse(values[4]),
                EffectNames = values[5].Split(',')
            };
        }
    }
}
