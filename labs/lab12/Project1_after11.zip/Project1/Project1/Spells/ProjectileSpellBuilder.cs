﻿using Microsoft.Xna.Framework.Graphics;
using Project1.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Spells
{
    public class ProjectileSpellBuilder : ISpellBuilder
    {
        private int cost;
        private IList<ICommand> effects;
        private Texture2D texture;

        private SpellEffectFactory factory;

        public ProjectileSpellBuilder()
        {
            factory = new SpellEffectFactory();
            effects = new List<ICommand>();
        }

        public ISpellBuilder AddEffect(string effectName)
        {
            effects.Add(factory.GetEffect(effectName));
            return this;
        }

        public ISpell CreateSpell(IWizard wizard)
        {
            return new ProjectileSpell(wizard, effects, cost, texture);
        }

        public ISpellBuilder SetSpellCost(int cost)
        {
            this.cost = cost;
            return this;
        }

        public ISpellBuilder SetTexture(Texture2D texture)
        {
            this.texture = texture;
            return this;
        }
    }
}
