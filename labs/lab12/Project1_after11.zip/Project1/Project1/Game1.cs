﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Project1.Actors;
using Project1.Commands;
using Project1.Factories;
using Project1.Worlds;
using System;

namespace Project1
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private SpriteFont healthFont;

        private Texture2D star;
        private GameWorld world;
        private WorldMap map;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;

            TargetElapsedTime = TimeSpan.FromSeconds(1d / 30d);
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
            _graphics.IsFullScreen = false;
            _graphics.PreferredBackBufferWidth = 800;
            _graphics.PreferredBackBufferHeight = 592;
            _graphics.ApplyChanges();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            // star = Content.Load<Texture2D>("star");
            healthFont = Content.Load<SpriteFont>("Health");
            IFactory factory = new ActorFactory();

            world = new GameWorld(800, 592);
            map = new WorldMap("Content/map01.tmx", "Content/tileset_basic.tsx", "tileset_basic", Content, world, factory);
            /*world.AddActor(factory.Create(Content, "Bomb", "bomb", 50, 50));
            PowerSwitch powerSwitch = (PowerSwitch)factory.Create(Content, "PowerSwitch", "switch", 100, 200);
            LightBulb bulb = (LightBulb)factory.Create(Content, "LightBulb", "bulb1", 200, 100);
            bulb.ConnectToSwitch(powerSwitch);
            LightBulb bulb2 = (LightBulb)factory.Create(Content, "LightBulb", "bulb2", 300, 100);
            LightBulb bulb3 = (LightBulb)factory.Create(Content, "LightBulb", "bulb3", 400, 100);
            bulb3.ConnectToSwitch(powerSwitch);
            CrackedLightBulb bulb4 = (CrackedLightBulb)factory.Create(Content, "CrackedLightBulb", "bulb4", 500, 100);
            bulb4.ConnectToSwitch(powerSwitch);
            world.AddActor(powerSwitch);
            world.AddActor(bulb);
            world.AddActor(bulb2);
            world.AddActor(bulb3);
            world.AddActor(bulb4);
            Player player = (Player)factory.Create(Content, "Player", "player", 300, 300);
            world.AddActor(player);

            world.AddActor(factory.Create(Content, "Star", "star", 400, 420));

            world.AddActor(factory.Create(Content, "Spike", "spike", 100, 440));
            world.AddActor(factory.Create(Content, "Spike", "spike", 80, 440));
            world.AddActor(factory.Create(Content, "Spike", "spike", 60, 440));
            world.AddActor(factory.Create(Content, "Spike", "spike", 40, 440));
            world.AddActor(factory.Create(Content, "Spike", "spike", 20, 440));
            world.AddActor(factory.Create(Content, "Spike", "spike", 0, 440));*/
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here

            base.Update(gameTime);
            KeyChecker.GetState();
            world.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            base.Draw(gameTime);

            /*_spriteBatch.Begin();
            _spriteBatch.Draw(star, new Vector2(100, 100), Color.White);
            _spriteBatch.End();*/

            map.DrawMap(_spriteBatch);
            world.Draw(_spriteBatch);

            Player player = world.GetActor("player") as Player;
            if (player != null)
            {
                string health = player.GetHealth().ToString();
                _spriteBatch.Begin();
                _spriteBatch.DrawString(healthFont, health, new Vector2(10, 10), Color.Black);
                _spriteBatch.End();
            }
        }
    }
}
