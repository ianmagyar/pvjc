﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Project1.Commands;
using Project1.Strategies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1.Actors
{
    public class AbstractCharacter : AbstractAnimatedActor, ICharacter
    {
        protected int health;
        protected ISpeedStrategy speedStrategy;
        protected double speed;
        protected List<ICommand> effects;

        public AbstractCharacter()
        {
            effects = new List<ICommand>();
            health = 100;
            speed = 1;
        }

        public AbstractCharacter(string name) : base(name)
        {
            effects = new List<ICommand>();
            health = 100;
            speed = 1;
        }

        public AbstractCharacter(string name, Texture2D texture, int rows, int columns) : base(name, texture, rows, columns)
        {
            effects = new List<ICommand>();
            health = 100;
            speed = 1;
        }

        public void AddEffect(ICommand effect)
        {
            effects.Add(effect);
        }

        public void ChangeHealth(int delta)
        {
            health = Math.Max(0, health + delta);
            if (health == 0 )
            {
                Die();
            }
        }

        public void Die()
        {
            RemoveFromWorld();
        }

        public double GetBaseSpeed()
        {
            return speed;
        }

        public int GetHealth()
        {
            return health;
        }

        public double GetSpeed()
        {
            return speedStrategy.GetSpeed(speed);
        }

        public void RemoveEffect(ICommand effect)
        {
            if (effects.Contains(effect))
            {
                effects.Remove(effect);
            }
        }

        public void SetSpeedStrategy(ISpeedStrategy strategy)
        {
            speedStrategy = strategy;
        }

        public ISpeedStrategy GetSpeedStrategy()
        {
            return speedStrategy;
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            foreach (ICommand effect in effects)
            {
                effect.Execute();
            }
        }
    }
}
