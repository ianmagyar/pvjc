﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Project1.Factories;
using System;
using System.Collections.Generic;
using System.Linq;
using TiledCS;

namespace Project1.Worlds
{
    public class WorldMap
    {
        private TiledMap _map;
        private TiledTileset _tileset;
        private Texture2D _tilesetTexture;
        private TiledLayer objectLayer;
        private TiledLayer wallLayer;

        private int _tileWidth;
        private int _tileHeight;
        private int _tilesetTilesWide;
        private int _tilesetTilesHeight;

        private List<TiledObject> objects;
        private GameWorld world;
        private IFactory aFactory;

        public WorldMap(string mapPath, string tilesetPath, string tilesetTexture, ContentManager content, GameWorld world, IFactory factory)
        {
            this.world = world;
            world.SetMap(this);
            aFactory = factory;

            _map = new TiledMap(mapPath);
            _tileset = new TiledTileset(tilesetPath);
            _tilesetTexture = content.Load<Texture2D>(tilesetTexture);

            _tileWidth = _tileset.TileWidth;
            _tileHeight = _tileset.TileHeight;
            _tilesetTilesWide = _tileset.Columns;
            _tilesetTilesHeight = _tileset.TileCount / _tileset.Columns;

            objectLayer = _map.Layers.First(l => l.name == "objects");
            wallLayer = _map.Layers.First(l => l.name == "walls");
            objects = objectLayer.objects.ToList<TiledObject>();

            foreach (TiledObject obj in objects)
            {
                world.AddActor(aFactory.Create(
                    content, obj.@class, obj.name, (int)obj.x, (int)obj.y
                ));
            }
        }

        public void DrawMap(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();

            for (var i = 0; i < _map.Layers[0].data.Length; i++)
            {
                int gid = _map.Layers[0].data[i];

                if (gid == 0)
                {

                }
                else
                {
                    int tileFrame = gid - 1;

                    var tile = _map.GetTiledTile(_map.Tilesets[0], _tileset, gid);

                    int column = tileFrame % _tilesetTilesWide;
                    int row = (int)Math.Floor((double)tileFrame / (double)_tilesetTilesWide);

                    float x = (i % _map.Width) * _map.TileWidth;
                    float y = (float)Math.Floor(i / (double)_map.Width) * _map.TileHeight;

                    Rectangle tilesetRec = new Rectangle(_tileWidth * column, _tileHeight * row, _tileWidth, _tileHeight);

                    spriteBatch.Draw(_tilesetTexture, new Rectangle((int)x, (int)y, _tileWidth, _tileHeight), tilesetRec, Color.White);
                }
            }

            spriteBatch.End();
        }

        public bool IsWall(int x, int y)
        {
            int x_id = x / _map.TileWidth;
            int y_id = y / _map.TileHeight;
            int tile_id = _map.Width * y_id + x_id;
            return wallLayer.data[tile_id] != 0;
        }
    }
}
