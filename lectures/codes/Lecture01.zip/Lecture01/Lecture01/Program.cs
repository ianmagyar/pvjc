﻿using System;

namespace Lecture01
{
    public class Student
    {
        private string firstName;
        private string familyName;
        private int grade;

        public Student()
        {

        }

        public Student(string firstName, string familyName)
        {
            // Console.WriteLine("I am here");
            this.firstName = firstName;
            this.familyName = familyName;
            this.grade = 0;
        }

        /*public Student(string firstName)
        {
            this.firstName = firstName;
            this.familyName = "Doe";
            this.grade = 0;
        }*/

        public Student(string firstName) : this(firstName, "Doe")
        {

        }

        public string GetName()
        {
            return this.firstName + " " + this.familyName;
        }

        public void SetName(string familyName)
        {
            this.familyName = familyName;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // pretazenie konstruktorov
            Student student1 = new Student();
            Console.WriteLine("Student 1's name is: " + student1.GetName());

            Student student2 = new Student("Janko", "Hrasko");
            Console.WriteLine("Student 2's name is: " + student2.GetName());

            Student student3 = new Student("Jane");
            Console.WriteLine("Student 3's name is: " + student3.GetName());

            // hodnotove vs referencne typy
            int x = 3;
            int y = x;
            x = 5;

            Console.WriteLine(x);
            Console.WriteLine(y);

            Student originalStudent = new Student("John", "Doe");
            Student copyStudent = originalStudent;

            originalStudent.SetName("Wick");

            Console.WriteLine("Original student name: " + originalStudent.GetName());
            Console.WriteLine("Copy student name: " + copyStudent.GetName());

        }
    }
}
