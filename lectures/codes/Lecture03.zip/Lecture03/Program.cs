﻿using System.Security.Cryptography;

namespace Lecture03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // pretazenie konstruktorov
            /*Student st1 = new Student();
            Console.WriteLine("St1's name is: " + st1.GetName());

            Student st2 = new Student("Janko", "Hrasko");
            Console.WriteLine("St2's name is: " + st2.GetName());
            Console.WriteLine("St2's name is: " + st2.Name);

            Student st3 = new Student("Jane");
            Console.WriteLine("St3's name is: " + st3.GetName());
            Console.WriteLine("St3's name is: " + st3.Name);

            Console.WriteLine(st3.Age);
            st3.Age = 20;
            Console.WriteLine(st3.Age);*/

            // Singleton inst = Singleton.GetInstance();
            Article a1 = new Article("a", 5, 100);
            Article a2 = new DiscountArticle("cheap", 5, 100, 0.1);

            Console.WriteLine(a1.GetPrice());
            Console.WriteLine(a2.GetPrice());
        }
    }
}