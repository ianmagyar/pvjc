﻿using System;
namespace Lecture03
{
    public class Animal
    {
        //pet - ako sloveso maznat

        private string Name;

        public Animal()
        {
            Console.WriteLine("konstruktor bez parametrov");
        }

        public Animal(string Name)
        {
            Console.WriteLine("Konstruktor s parametrom");
            this.Name = Name;
        }

        public virtual void Pet()
        {
            Console.WriteLine("no sound");
        }

        public virtual void Eating()
        {
            Console.WriteLine("jedlo");
        }

        public virtual void Seeing()
        {
            Console.WriteLine("Nevidim");
        }

}
}
