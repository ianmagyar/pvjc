﻿using System;
namespace Lecture03
{
    public class Dog : Animal
    {
        private string Name;

        public Dog(string Name) : base(Name)
        {
            this.Name = Name;
        }

        public override void Seeing()
        {
            Console.WriteLine("Vidim");
        }

        //public new void Pet()

        //polymorfizmus
        public override void Pet()
        {
            Console.WriteLine(Name + " : hav hav");
        }

        public void Pet(string X)
        {
            Console.WriteLine(Name + X + " : hav hav");
        }

        public override void Eating()
        {
            base.Eating();
            Console.WriteLine(Name + " zerie granule");
        }

    }
}
