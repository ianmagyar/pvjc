﻿using System;
namespace Lecture03
{
    public class PetOwner<T> where T : Animal
    {
        public T animal;

        public void SetPet(T p)
        {
            this.animal = p;
        }
    }
   
}
