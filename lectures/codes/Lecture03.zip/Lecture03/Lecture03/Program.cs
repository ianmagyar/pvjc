﻿using System.Security.Cryptography;

namespace Lecture03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Article a1 = new Article("a", 5, 100);
            Article a2 = new DiscountArticle("cheap", 5, 100, 0.1);

            //Console.WriteLine(a1.price);

            /*Console.WriteLine(a1.GetPrice());
            Console.WriteLine(a1.GetQuantity());
            Console.WriteLine(a2.GetPrice());
            Console.WriteLine(a2.GetQuantity());
            a2.Update(20);
            Console.WriteLine(a2.GetQuantity());*/

            Article a3 = new DiscountArticle("b", 5, 100, 0.2);
            Console.WriteLine(a3.GetPrice());
            // Console.WriteLine(a3.GetDiscount());
            // Article a3 = new Article("a3", 5, 100);
            DiscountArticle a4 = (DiscountArticle)a3;
            Console.WriteLine(a4.GetDiscount());

        }
    }
}