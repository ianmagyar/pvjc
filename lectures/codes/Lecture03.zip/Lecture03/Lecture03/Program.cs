﻿using System;

namespace Lecture03
{
    class Program
    {
        static void Main(string[] args)
        {
            Dog pes1 = new Dog("Benny");
            Cat macka1 = new Cat("Cecil");

            Animal a1 = new Animal("Benn");

            pes1.Pet();
            macka1.Pet();

            pes1.Eating();
            pes1.Seeing();

            //a1.Eating();

            Animal a = pes1;
            a.Seeing();
            //a.Pet();
            //a.Eating();

            //Animal b = macka1;
            //b.Pet();
            //b.Eating();


        }
    }
}














            //PetOwner<Cat> catOwner = new PetOwner<Cat>();    // for this instance, Cat stands in for T
            //PetOwner<Dog> dogOwner = new PetOwner<Dog>();    // for this instance, Dog stands in for T
            //PetOwner<Animal> petOwner = new PetOwner<Animal>();    // for this instance, Pet stands in for T

            //petOwner.animal = new Cat("Helena");    // OK
            //petOwner.animal = new Dog("Jozi");

            //catOwner.animal = new Cat("Helena");    // OK
            //catOwner.animal = new Dog("Jozi");
//        }
//    }


//}
