﻿using System;
namespace Lecture03
{

    class Cat : Animal
    {
        private string Name;
        public Cat(string Name) : base(Name)
        {
            this.Name = Name;
        }

        //public new void Pet()

        //polymorfizmus
        public override void Pet()
        {
            Console.WriteLine(Name + " : miau maiu");
        }

    }
}
