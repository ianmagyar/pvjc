﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture03
{
    public class DiscountArticle : Article
    {
        private double discount;

        public DiscountArticle(string name, int quantity, double price, double discount) : base(name, quantity, price)
        {
            this.discount = discount;
        }

        public double GetDiscount() { return discount; }
        public void SetDiscount(double discount) { this.discount = discount; }

        public override double GetPrice()
        {
            return base.GetPrice() * (1 - this.discount);
        }
    }
}
