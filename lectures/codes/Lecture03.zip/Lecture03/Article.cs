﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture03
{
    public class Article
    {
        private string name;
        private int quantity;
        private double price;

        public Article(string name, int quantity, double price)
        {
            this.name = name;
            this.quantity = quantity;
            this.price = price;
        }

        public void Update(int quantity)
        {
            this.quantity += quantity;
        }

        public virtual double GetPrice()
        {
            return price;
        }
    }
}
