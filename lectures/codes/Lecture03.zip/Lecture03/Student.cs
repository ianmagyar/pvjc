﻿namespace Lecture03
{
    public class Student
    {
        private int id;
        private string firstName;
        private string lastName;
        private int grade;

        private static int counter = 1;

        public string Name
        {
            get
            {
                return this.firstName + " " + this.lastName;
            }
            set
            {
                this.lastName = value;
            }
        }
        public int Age { get; set; } = 19;

        public Student()
        {
            
        }

        public Student(string firstName, string lastName)
        {
            // Console.WriteLine("calling constructor 2");
            this.firstName = firstName;
            this.lastName = lastName;
            grade = 0;
            id = counter;
            counter++;
        }

        //public Student(string firstName)
        //{
        //    this.firstName = firstName;
        //    this.lastName = "Doe";
        //    grade = 0;
        //}

        public Student(string firstName) : this(firstName, "Doe")
        {
            
        }

        public string GetName()
        {
            return this.firstName + " " + this.lastName;
        }

        public void SetName(string lastName)
        {
            this.lastName = lastName;
        }

        public int GetGrade()
        {
            return this.grade;
        }

        public void SetGrade(int grade)
        {
            int oldValue = this.GetGrade();
            this.grade = grade;
        }
    }
}
