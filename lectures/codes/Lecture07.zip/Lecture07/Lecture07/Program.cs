﻿using System;
using Lecture07.GenericClassDemo;
using Lecture07.SubtypeGenericsDemo;
using Lecture07.WildcardDemo;

namespace Lecture07
{
    class Program
    {
        static void BoxingDemo()
        {
            int i = 123;

            object o = i;

            i = 456;

            System.Console.WriteLine("The value-type value = {0}", i);
            System.Console.WriteLine("The object-type value = {0}", o);
        }

        static void UnboxingDemo()
        {
            int i = 123;
            object o = i;

            try
            {
                //int j = (short)o;
                int j = (int)o;

                System.Console.WriteLine("Unboxing OK.");
            }
            catch (System.InvalidCastException e)
            {
                System.Console.WriteLine("{0} Error: Incorrect unboxing.", e.Message);
            }
        }

        static void GenericListDemo()
        {
            GenericList<int> listInt = new GenericList<int>();
            listInt.Add(3);
            //listInt.Add("a string");

            GenericList<string> listString = new GenericList<string>();
            listString.Add("");
            //listString.Add(3);
        }

        static void GenericLinkedListDemo()
        {
            GenericLinkedList<int> testList = new GenericLinkedList<int>();

            for (int x = 0; x < 10; x++)
            {
                testList.AddHead(x);
            }

            foreach (int i in testList)
            {
                System.Console.WriteLine(i);
            }
        }

        static void WildcardDemo()
        {
            SortedList<Person> list = new SortedList<Person>();

            string[] names = new string[]
            {
                "Franscoise",
                "Bill",
                "Li",
                "Sandra",
                "Gunnar",
                "Alok",
                "Hiroyuki",
                "Maria",
                "Alessandro",
                "Raul"
            };

            int[] ages = new int[] { 45, 19, 28, 23, 18, 9, 108, 72, 30, 35 };

            for (int x = 0; x < 10; x++)
            {
                list.AddHead(new Person(names[x], ages[x]));
            }

            foreach (Person p in list)
            {
                System.Console.WriteLine(p.ToString());
            }
            System.Console.WriteLine("---------------");

            list.BubbleSort();

            foreach (Person p in list)
            {
                System.Console.WriteLine(p.ToString());
            }
        }

        static void Swap<T>(ref T lhs, ref T rhs)
        {
            T temp;
            temp = lhs;
            lhs = rhs;
            rhs = temp;
        }

        static void GenericMethodDemo()
        {
            int a = 1;
            int b = 2;

            System.Console.WriteLine(a + " " + b);
            Swap<int>(ref a, ref b);
            System.Console.WriteLine(a + " " + b);

            string s = "a";
            string t = "b";
            System.Console.WriteLine(s + " " + t);
            Swap<string>(ref s, ref t);
            System.Console.WriteLine(s + " " + t);
        }

        static void BadDowncastingDemo()
        {
            BadDownCasting example = new BadDownCasting();
            example.AddElement(new Developer("Janko", "Hrasko"));
            example.AddElement(new Tester("John", "Doe"));
            example.AddElement(new Developer("Jane", "Doe"));
            example.AddElement(new String("Name Surname"));

            Object elementAt1 = example.GetElement(1);
            //Console.WriteLine(elementAt1.GiveName());

            //Developer devAt1 = (Developer)elementAt1;
            //Console.WriteLine(devAt1.GiveName());

            Employee employeeAt1 = (Employee)elementAt1;
            Console.WriteLine(employeeAt1.GiveName());

            Tester testerAt1 = (Tester)elementAt1;
            Console.WriteLine(testerAt1.GiveName());

            Object lastelement = example.GetElement(3);
            Employee lastEmployee = (Employee)lastelement;
            Console.WriteLine(lastEmployee.GiveName());
        }

        static void GenericSolutionDemo()
        {
            GenericSolution<Employee> employeeList = new GenericSolution<Employee>();
            employeeList.AddElement(new Developer("Janko", "Hrasko"));
            employeeList.AddElement(new Developer("John", "Doe"));
            employeeList.AddElement(new Tester("Jane", "Doe"));
            //employeeList.AddElement(new String("Name Surname")); // compile-time error

            Employee employeeAt1 = employeeList.GetElement(1);
            Console.WriteLine(employeeAt1.GiveName());

            GenericSolution<Developer> developerList = new GenericSolution<Developer>();
            developerList.AddElement(new Developer("Janko", "Hrasko"));
            developerList.AddElement(new Developer("John", "Doe"));
            //developerList.AddElement(new Tester("Jane", "Doe")); // cannot add testers to a list of developers

            Employee developerAt1 = developerList.GetElement(1); // can still use common interface
            Console.WriteLine(developerAt1.GiveName());
            //Console.WriteLine(developerAt1.GiveLanguage()); // but cannot use class-specific behavior

            Developer devAt1 = developerList.GetElement(1); // or can convert immediately
            Console.WriteLine(devAt1.GiveName());
            Console.WriteLine(devAt1.GiveLanguage()); // class-specific behavior is available
        }

        static void Main(string[] args)
        {
            //BadDowncastingDemo();

            //BoxingDemo();

            //UnboxingDemo();

            //GenericListDemo();

            //GenericLinkedListDemo();

            //WildcardDemo();

            //GenericMethodDemo();

            GenericSolutionDemo();
        }
    }
}
