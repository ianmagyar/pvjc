﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture07.GenericClassDemo
{
    class GenericLinkedList<T>
    {
        private class Node
        {
            private Node next;
            public Node Next
            {
                get { return next; }
                set { next = value; }
            }

            private T data;
            public T Data
            {
                get { return data; }
                set { data = value; }
            }

            public Node(T value)
            {
                next = null;
                data = value;
            }
        }

        private Node head;

        public GenericLinkedList()
        {
            head = null;
        }

        public void AddHead(T t)
        {
            Node n = new Node(t);
            n.Next = head;
            head = n;
        }

        public IEnumerator<T> GetEnumerator()
        {
            Node current = head;

            while (current != null)
            {
                yield return current.Data;
                current = current.Next;
            }
        }
    }
}
