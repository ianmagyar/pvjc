﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture07.GenericClassDemo
{
    public class GenericList<T>
    {
        public void Add(T input) { }
    }
    
}
