﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture07.SubtypeGenericsDemo
{
    public class Tester : Employee
    {
        public Tester() : base() { }

        public Tester(string fName, string lName) : base(fName, lName) { }
    }
}
