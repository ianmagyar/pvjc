﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace Lecture07.SubtypeGenericsDemo
{
    class GenericSolution<T> where T : Employee
    {
        private List<T> elements;

        public GenericSolution()
        {
            elements = new List<T>();
        }

        public void AddElement(T t)
        {
            elements.Add(t);
        }

        public T GetElement(int idx)
        {
            return elements.ElementAt(idx);
        }
    }
}
