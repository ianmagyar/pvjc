﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture07.SubtypeGenericsDemo
{
    public class Developer : Employee
    {
        private string language;

        public Developer() : base() { }

        public Developer(string fName, string lName) : base(fName, lName)
        {
            language = "C#";
        }

        public Developer(string fName, string lName, string lang) : base(fName, lName)
        {
            language = lang;
        }

        public string GiveLanguage()
        {
            return language;
        }
    }
}
