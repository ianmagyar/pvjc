﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture07.SubtypeGenericsDemo
{
    public class Employee
    {
        private string firstName;
        private string lastName;

        public Employee() { }
        public Employee(string fName, string lName)
        {
            firstName = fName;
            lastName = lName;
        }

        public string GiveName()
        {
            return firstName + " " + lastName;
        }
    }
}
