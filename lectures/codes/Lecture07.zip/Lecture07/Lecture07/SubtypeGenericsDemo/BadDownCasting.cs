﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace Lecture07.SubtypeGenericsDemo
{
    public class BadDownCasting
    {
        private List<Object> elements;

        public BadDownCasting()
        {
            elements = new List<Object>();
        }

        public void AddElement(Object obj)
        {
            elements.Add(obj);
        }

        public Object GetElement(int index)
        {
            return elements.ElementAt(index);
        }
    }
}
