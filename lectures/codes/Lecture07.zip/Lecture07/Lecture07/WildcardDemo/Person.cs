﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Lecture07.WildcardDemo
{
    public class Person : IComparable<Person>
    {
        private string name;
        private int age;

        public Person(string s, int i)
        {
            name = s;
            age = i;
        }

        public int CompareTo(Person p)
        {
            return age - p.GetAge();
        }

        public int GetAge()
        {
            return age;
        }

        public override string ToString()
        {
            return name + ":" + age;
        }

        public bool Equals(Person p)
        {
            return (this.age == p.GetAge());
        }
    }
}
