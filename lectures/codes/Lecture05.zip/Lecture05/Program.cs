﻿using System;
using Lecture05.OverloadingDemo;
using Lecture05.DowncastingDemo;
using Lecture05.RectanglesLSP;

namespace Lecture05
{
    class Program
    {
        public static void OverloadingDemo()
        {
            Utility util = new Utility();
            SubUtility subUtil = new SubUtility();

            Console.WriteLine("util is a(n) " + util.TypeAsString(util));
            Console.WriteLine("'string' is a(n) " + util.TypeAsString("string"));
            Console.WriteLine("is util a string? " + util.IsString(util));
            Console.WriteLine("is 'string' is a string? " + util.IsString("string"));

            Console.WriteLine("util is a(n) " + subUtil.TypeAsString(util));
            Console.WriteLine("'string' is a(n) " + subUtil.TypeAsString("string"));
            Console.WriteLine("is util a string? " + subUtil.IsString(util));
            Console.WriteLine("is 'string' is a string? " + subUtil.IsString("string"));
            Console.WriteLine("");

            Object obj = new String("string");
            Console.WriteLine("util is a(n) " + util.TypeAsString(util));
            Console.WriteLine("'string' is a(n) " + util.TypeAsString(new String("string")));
            Console.WriteLine("is util a string? " + util.IsString(util));
            Console.WriteLine("is 'string' is a string? " + util.IsString(new String("string")));

            Console.WriteLine("util is a(n) " + subUtil.TypeAsString(util));
            Console.WriteLine("'string' is a(n) " + subUtil.TypeAsString(new String("string")));
            Console.WriteLine("is util a string? " + subUtil.IsString(util));
            Console.WriteLine("is 'string' is a string? " + subUtil.IsString(new String("string")));
        }

        public static void DowncastingDemo()
        {
            Person p = new Student("Janko", "Hrasko");
            Console.WriteLine(p.GiveName());
            // Console.WriteLine(p.GiveYear()); // nemozeme zavolat, kedze trieda Person nedefinuje metodu

            Student s = (Student)p;
            Console.WriteLine(s.GiveName());
            Console.WriteLine(s.GiveYear());

            Object obj = new Student("John", "Doe");
            Student s2 = (Student)obj;
            Console.WriteLine(s2.GiveName());
            Console.WriteLine(s2.GiveYear());

            Object wrong = new String("Jane Doe");
            Student s3 = (Student)wrong;

            Person p4 = new Person("Jane", "Doe");
            // Student s4 = (Student)p4;
            Object o4 = (Object)p4;
        }

        public static void BadDowncastingDemo()
        {
            BadDowncastingContainer example = new BadDowncastingContainer();

            example.AddElement(new Student("Janko", "Hrasko"));
            example.AddElement(new Person("John", "Doe"));
            example.AddElement(new Student("Jane", "Doe"));

            Object elementAt1 = example.GetElement(1);
            Object elementAt2 = example.GetElement(2);
            // elementAt1.GiveName();

            Student studentAt2 = (Student)elementAt1;
            Console.WriteLine(studentAt2.GiveName());
            Console.WriteLine(studentAt2.GiveYear());
        }

        public static void TestRectangleArea(Rectangle rectangle)
        {
            rectangle.SetWidth(5.0);
            rectangle.SetHeight(3.0);
            Console.WriteLine("Width is  5.0, height is 3.0, area is " + rectangle.GetArea());

            if (rectangle.GetArea() == 15.0)
            {
                Console.WriteLine("Everything seems fine");
            }
            else
            {
                Console.WriteLine("Something's off...");
            }
        }

        public static void RectangleDemo()
        {
            Rectangle testRectangle = new Rectangle(1.0, 1.0);
            TestRectangleArea(testRectangle);

            Square testSquare = new Square(1.0);
            TestRectangleArea(testSquare);
        }

        static void Main(string[] args)
        {
            // OverloadingDemo();

            // DowncastingDemo();

            // BadDowncastingDemo();

            RectangleDemo();
        }
    }
}
