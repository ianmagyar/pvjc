﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture05.OverloadingDemo
{
    class SubUtility : Utility
    {
        public SubUtility() : base() { }

        public Boolean IsString(String str) { return true; }
    }
}
