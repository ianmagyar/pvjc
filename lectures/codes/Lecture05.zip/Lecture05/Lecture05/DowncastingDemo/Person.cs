﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture05.DowncastingDemo
{
    class Person
    {
        private string firstName;
        private string lastName;

        public Person() { }
        public Person(string firstName, string lastName)
        {
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public string GiveName()
        {
            return this.firstName + " " + this.lastName;
        }
    }
}
