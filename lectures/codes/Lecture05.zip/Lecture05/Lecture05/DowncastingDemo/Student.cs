﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture05.DowncastingDemo
{
    class Student : Person
    {
        private int year;

        public Student() : base() { }
        
        public Student(string firstName, string lastName) : base(firstName, lastName)
        {
            this.year = 1;
        }

        public int GiveYear()
        {
            return this.year;
        }
    }
}
