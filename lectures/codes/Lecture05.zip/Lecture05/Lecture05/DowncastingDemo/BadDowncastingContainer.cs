﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace Lecture05.DowncastingDemo
{
    class BadDowncastingContainer
    {
        private List<Object> elements;

        public BadDowncastingContainer()
        {
            elements = new List<Object>();
        }

        public void AddElement(Object obj)
        {
            elements.Add(obj);
        }

        public Object GetElement(int index)
        {
            return elements.ElementAt(index);
        }
    }
}
