﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture05.OverloadingDemo
{
    class Utility
    {
        public Utility()
        {
            Console.WriteLine("calling Utility constructor");
        }

        public String TypeAsString(Object obj) { return "object"; }
        public String TypeAsString(String str) { return "string"; }

        public Boolean IsString(Object obj) { return false; }
    }
}
