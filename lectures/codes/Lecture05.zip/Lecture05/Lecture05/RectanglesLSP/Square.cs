﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture05.RectanglesLSP
{
    class Square : Rectangle
    {
        public Square(double size) : base(size, size) { }

        public override void SetWidth(double width)
        {
            base.SetHeight(width);
            base.SetWidth(width);
        }

        public override void SetHeight(double height)
        {
            base.SetHeight(height);
            base.SetWidth(height);
        }
    }
}
