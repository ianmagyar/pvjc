﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture05.RectanglesLSP
{
    class Rectangle
    {
        private double width;
        private double height;

        public Rectangle(double width, double height)
        {
            this.width = width;
            this.height = height;
        }

        public double GetWidth()
        {
            return this.width;
        }

        public virtual void SetWidth(double width)
        {
            this.width = width;
        }

        public double GetHeight()
        {
            return this.height;
        }
        public virtual void SetHeight(double height)
        {
            this.height = height;
        }

        public double GetArea()
        {
            return this.width * this.height;
        }
    }
}
