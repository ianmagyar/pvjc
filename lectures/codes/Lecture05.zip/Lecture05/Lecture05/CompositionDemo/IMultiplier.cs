﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture05.CompositionDemo
{
    interface IMultiplier
    {
        public double Multiply(double number);
    }
}
