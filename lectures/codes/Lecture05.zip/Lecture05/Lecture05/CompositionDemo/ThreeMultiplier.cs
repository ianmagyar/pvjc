﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture05.CompositionDemo
{
    class ThreeMultiplier : IMultiplier
    {
        public ThreeMultiplier() { }
        public double Multiply(double number)
        {
            return number * 3;
        }
    }
}
