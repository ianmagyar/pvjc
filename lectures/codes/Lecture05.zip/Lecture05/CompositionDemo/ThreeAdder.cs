﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture05.CompositionDemo
{
    public class ThreeAdder : IAdder
    {
        public ThreeAdder() { }

        public double Add(double number)
        {
            return number + 3;
        }
    }
}
