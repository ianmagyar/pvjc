﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture05.CompositionDemo
{
    interface IAdder
    {
        public double Add(double number);
    }
}
