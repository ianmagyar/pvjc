﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture05.CompositionDemo
{
    class TwoAdder : IAdder
    {
        public TwoAdder() { }
        public double Add(double number)
        {
            return number + 2;
        }
    }
}
