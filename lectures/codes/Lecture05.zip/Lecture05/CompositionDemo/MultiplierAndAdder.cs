﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture05.CompositionDemo
{
    class MultiplierAndAdder
    {
        private IAdder adder;
        private ThreeMultiplier multiplier;

        public MultiplierAndAdder(IAdder adder) {
            this.adder = adder;
            multiplier = new ThreeMultiplier();
        }

        public double Process(double number)
        {
            return adder.Add(multiplier.Multiply(number));
        }
    }
}
