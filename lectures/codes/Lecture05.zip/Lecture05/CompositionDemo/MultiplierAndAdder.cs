﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture05.CompositionDemo
{
    class MultiplierAndAdder
    {
        private TwoAdder adder;
        private ThreeMultiplier multiplier;

        public MultiplierAndAdder() {
            adder = new TwoAdder();
            multiplier = new ThreeMultiplier();
        }

        public double Process(double number)
        {
            return adder.Add(multiplier.Multiply(number));
        }
    }
}
