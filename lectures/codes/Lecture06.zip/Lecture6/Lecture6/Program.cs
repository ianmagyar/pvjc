﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Lecture6
{
    class Program
    {
        static void Main(string[] args)
        {
            //File f = new File();
            //f.Name = ".gitignore";
            //File file = new File 
            //{ 
            //    Name = ".gitignore",
            //    FileSize = 4096 
            //};
            ////f.Name = "Merlin.sln";
            //List<File> files = new List<File> { file, new File { Name = "Merlin.sln" } };

            //List<int> allNumbers = new List<int>();
            //for (int i = 1; i <= 10; i++)
            //{
            //    allNumbers.Add(i);
            //}

            //Func<int, bool> evenFilter = x =>
            //{
            //    return x % 2 == 0;
            //};

            //Func<int, bool> oddFilter = x =>
            //{
            //    return x % 2 != 0;
            //};

            //List<int> filteredNumbers = allNumbers.Where(oddFilter).ToList();

            //foreach(int x in filteredNumbers)
            //{
            //    Console.WriteLine(x);
            //}

            //Dictionary<int, string> spaces = new Dictionary<int, string>();
            //spaces.Add(0, "");
            //spaces.Add(1, "\t");

            //Console.WriteLine(EmptySpaceProvider.GetInstance().GetSpaces(1) + ".gitignore");
            //Console.WriteLine(EmptySpaceProvider.GetInstance().GetSpaces(2) + "resources");
            //string s = String.Format("some random text with numbers {0}, {1}, {0}", 5, 11);
            //Console.WriteLine(s);

            File f1 = new File { Name = ".gitginore", FileSize = 4096 };
            File f2 = new File { Name = "Merlin.sln", FileSize = 1594 };
            File f3 = new File { Name = "AbstractSwitchable.cs", FileSize = 538 };
            File f4 = new File { Name = "Fall.cs", FileSize = 768 };
            File f5 = new File { Name = "Merlin.csproj", FileSize = 2547 };

            Directory d1 = new Directory { Name = "Merlin" };
            Directory d2 = new Directory { Name = "Merlin" };
            Directory d3 = new Directory { Name = "Actors" };
            Directory d4 = new Directory { Name = "Commands" };

            d1.Add(d2);
            d1.Add(f1);
            d1.Add(f2);

            d2.Add(d3);
            d2.Add(d4);
            d2.Add(f5);

            d3.Add(f3);
            d4.Add(f4);

            d1.PrintInfo(0);


            //foreach (File f in files)
            //{
            //    Console.WriteLine(f.Name);
            //}

            //var e = files.GetEnumerator();
            //while(e.MoveNext())
            //{
            //    Console.WriteLine(e.Current.Name);
            //}

            //for(int i = 0; i < files.Count; i++)
            //{
            //    Console.WriteLine(files[i].Name);
            //}

            //Console.WriteLine(file.Name);
        }
    }
}
