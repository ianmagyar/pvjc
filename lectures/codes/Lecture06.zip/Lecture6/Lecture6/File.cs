﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture6
{
    public class File : AbstractFileSystemComponent
    {
        private string name;
        public long FileSize { get; set; }

        //public string Name { get; set; }
        public string Name 
        { 
            get 
            { 
                return name; 
            } 
            init
            { 
                name = value.Trim(); 
            } 
        }

        private void SetName(string value)
        {
            this.name = value.Trim();
        }

        public string GetName()
        {
            return name;
        }

        public override long GetSize()
        {
            return FileSize;
        }

        public override void PrintInfo(int depth)
        {
            string s = EmptySpaceProvider.GetInstance().GetSpaces(depth);
            Console.WriteLine("{0}{1} - {2}B", s, Name, GetSize());
        }
    }
}
