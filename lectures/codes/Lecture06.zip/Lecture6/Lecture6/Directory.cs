﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture6
{
    public class Directory : AbstractFileSystemComponent
    {

        public string Name { get; set; }

        private List<IFileSystemComponent> components;

        public Directory()
        {
            components = new List<IFileSystemComponent>();
        }

        public override long GetSize()
        {
            long size = 0;
            components.ForEach(component =>
            {
                size += component.GetSize();
            });

            return size;
        }

        public override void Add(IFileSystemComponent component)
        {
            components.Add(component);
        }

        public override void Remove(IFileSystemComponent component)
        {
            components.Remove(component);
        }

        public override void PrintInfo(int depth)
        {
            string s = EmptySpaceProvider.GetInstance().GetSpaces(depth);
            Console.WriteLine("{0}{1} - {2}B", s, Name, GetSize());
            foreach(IFileSystemComponent component in components)
            {
                component.PrintInfo(depth + 1);
            }
        }
    }
}
