﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture6
{
    public class EmptySpaceProvider
    {

        private Dictionary<int, string> spaces;

        private static EmptySpaceProvider instance;
        private EmptySpaceProvider()
        {
            spaces = new Dictionary<int, string>();
        }

        public static EmptySpaceProvider GetInstance()
        {
            if (instance == null)
            {
                instance = new EmptySpaceProvider();
            }

            return instance;
        }

        public string GetSpaces(int length)
        {
            if (!spaces.ContainsKey(length))
            {
                string value = "";
                for (int i = 0; i < length; i++)
                {
                    value += "\t";
                }
                spaces.Add(length, value);
            }

            return spaces[length];
        }

    }
}
