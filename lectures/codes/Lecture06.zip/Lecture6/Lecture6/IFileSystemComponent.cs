﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture6
{
    public interface IFileSystemComponent
    {
        void Add(IFileSystemComponent component);
        void Remove(IFileSystemComponent component);
        void PrintInfo(int depth);
        long GetSize();
    }
}
