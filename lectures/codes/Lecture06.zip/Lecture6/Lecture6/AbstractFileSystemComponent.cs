﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture6
{
    public abstract class AbstractFileSystemComponent : IFileSystemComponent
    {
        public virtual void Add(IFileSystemComponent component)
        {
            throw new NotSupportedException();
        }

        public abstract long GetSize();

        public abstract void PrintInfo(int depth);

        public virtual void Remove(IFileSystemComponent component)
        {
            throw new NotSupportedException();
        }
    }
}
