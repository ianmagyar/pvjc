﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture04.interfacedemo
{
    abstract class AbstractMoving
    {
        protected AbstractMoving() { }

        public abstract void Move();
    }
}
