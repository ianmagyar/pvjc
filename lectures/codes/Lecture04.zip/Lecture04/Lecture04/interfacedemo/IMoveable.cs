﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture04.interfacedemo
{
    interface IMoveable
    {
        public void Move();
    }
}
