﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture04.interfacedemo
{
    abstract class Actor
    {
        protected int x;
        protected int y;
        protected string name;

        protected Actor() { }

        protected Actor(int x, int y, string name)
        {
            this.x = x;
            this.y = y;
            this.name = name;
        }
    }
}
