﻿using System;
using Lecture04.demo;
using Lecture04.interfacedemo;

namespace Lecture04
{
    class Program
    {
        static void PersonDemo()
        {
            //Person example = new Person("Janko", "Hrasko");
            //Console.WriteLine(example.ToString());

            //Person example2 = new Person("John", "Doe");
            //Console.WriteLine(example2.ToString());

            Student student1 = new Student("Jane", "Doe");
            Console.WriteLine(student1);
            student1.Act();

            Teacher teacher1 = new Teacher("Jan", "Komensky");
            teacher1.Act();
        }

        static void InterfaceDemo()
        {
            Hero thor = new Hero(10, 10, "Thor");

            thor.Move();
            thor.Die();
        }

        static void CompositionDemo()
        {
            
        }

        static void Main(string[] args)
        {
            PersonDemo();

            InterfaceDemo();
        }
    }
}
