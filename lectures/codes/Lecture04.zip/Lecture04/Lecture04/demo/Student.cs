﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture04.demo
{
    class Student : Person
    {
        private int year;

        public Student(string firstName, string lastName) : base(firstName, lastName)
        {
            this.year = 1;
        }

        public override void Act()
        {
            Console.WriteLine("{0} {1} is studying", this.firstName, this.lastName);
        }

        public void Graduate()
        {
            if (this.year < 5)
                this.year++;
            else
            {
                Console.WriteLine("{0} {1} graduates", this.firstName, this.lastName);
            }
        }
    }
}
