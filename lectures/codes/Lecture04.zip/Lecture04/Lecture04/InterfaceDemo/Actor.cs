﻿namespace Lecture04.InterfaceDemo
{
    abstract class Actor
    {
        protected int x;
        protected int y;
        protected string name;

        protected Actor() { }

        protected Actor(int x, int y, string name)
        {
            this.x = x;
            this.y = y;
            this.name = name;
        }
    }
}
