﻿namespace Lecture04.AbstractDemo
{
    class Teacher : Person
    {
        public Teacher(string firstName, string lastName) : base(firstName, lastName)
        {

        }

        public override void Act()
        {
            Console.WriteLine("{0} {1} is teaching", this.firstName, this.lastName);
        }
    }
}
