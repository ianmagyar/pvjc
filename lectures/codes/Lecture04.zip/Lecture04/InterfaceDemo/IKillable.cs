﻿namespace Lecture04.InterfaceDemo
{
    interface IKillable
    {
        public void Die();
    }
}
