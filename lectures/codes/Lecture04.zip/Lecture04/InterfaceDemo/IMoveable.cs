﻿namespace Lecture04.InterfaceDemo
{
    interface IMoveable
    {
        public void Move();
    }
}
