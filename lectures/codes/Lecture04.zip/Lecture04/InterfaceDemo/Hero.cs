﻿namespace Lecture04.InterfaceDemo
{
    class Hero : Actor, IMoveable, IKillable
    {
        public Hero() : base() { }

        public Hero(int x, int y, string name) : base(x, y, name) { }

        public void Move()
        {
            this.x++;
            this.y++;
            Console.WriteLine(String.Format("{0} moved to [{1}, {2}]", this.name, this.x, this.y));
        }

        public void Die()
        {
            Console.WriteLine(this.name + " died");
        }
    }
}
