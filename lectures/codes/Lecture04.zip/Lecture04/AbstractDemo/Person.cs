﻿namespace Lecture04.AbstractDemo
{
    public abstract class Person
    {
        protected string firstName;
        protected string lastName;
        protected int selfId;

        protected static int id = 1;

        protected Person(string firstName, string lastName)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.selfId = id;
            id++;
        }

        public override string ToString()
        {
            return String.Format("{0} {1} ({2})", this.firstName, this.lastName, this.selfId);
        }

        public abstract void Act();
    }
}
