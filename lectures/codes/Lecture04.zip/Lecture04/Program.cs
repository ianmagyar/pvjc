﻿using Lecture04.AbstractDemo;
using Lecture04.InterfaceDemo;

namespace Lecture04
{
    internal class Program
    {
        static void PersonDemo()
        {
            //Person example = new Person("Janko", "Hrasko");
            //Console.WriteLine(example.ToString());

            Person example2 = new Student("John", "Doe");
            Console.WriteLine(example2.ToString());
            //example2.Graduate();

            Student st = (Student)example2;
            st.Graduate();

            Person student1 = new Student("Jane", "Doe");
            Console.WriteLine(student1);
            student1.Act();
            //student1.Graduate();

            Person teacher1 = new Teacher("Jan", "Komensky");
            teacher1.Act();
        }

        static void InterfaceDemo()
        {
            Hero thor = new Hero(10, 10, "Thor");

            thor.Move();
            thor.Die();
        }

        static void Main(string[] args)
        {
            // PersonDemo();

            InterfaceDemo();
        }
    }
}