﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture08
{
    class MyCustomException : Exception
    {
        public MyCustomException(string message) : base(message) { }

        public int ErrorCode { get; set; }
    }
}
