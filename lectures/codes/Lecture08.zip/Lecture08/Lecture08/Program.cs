﻿using System;

namespace Lecture08
{
    public class Program
    {
        static void TryCatchFinallyBasic()
        {
            int a = 0;
            try
            {
                bool overflow = true;
                bool outOfBounds = true;
                a = 10;

                if (overflow) {
                    throw new OverflowException();
                }
                Console.WriteLine("first error passed");
                a = 20;

                if (outOfBounds)
                {
                    throw new IndexOutOfRangeException();
                }
            }
            catch (OverflowException ex)
            {
                Console.WriteLine("Processing OverflowException");
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine("Processing IndexOutOfRangeException");
            }
            finally
            {
                Console.WriteLine(a);
                Console.WriteLine("Code that always executes");
            }
        }

        static void NumberWithTry(string n)
        {
            if (n is null) throw new ArgumentNullException();
            try
            {
                int i = int.Parse(n);  // can generate format and overflow exception
                Console.WriteLine("Parsed to " + i);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (OverflowException ex)  // each catch block has its own scope, hence the same variable name
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void NumberElegant(string n)
        {
            if (n is null) throw new ArgumentNullException();
            if (int.TryParse(n, out int i))
            {
                Console.WriteLine("Parsed to " + i);
            }
            else
            {
                Console.WriteLine("Not a number");
            }
        }

        static void BestPractice()
        {
            while (true)
            {
                try
                {
                    string userInput;
                    Console.Write("Input a number between 0 and 5 or hit return to exit: ");
                    userInput = Console.ReadLine();

                    if (string.IsNullOrEmpty(userInput))
                    {
                        break;  // exits try block and while loop
                    }

                    int index = Convert.ToInt32(userInput);
                    if (index < 0 || index > 5)
                    {
                        throw new IndexOutOfRangeException("You typed in " + index);
                    }
                    Console.WriteLine("Your number was " + index);
                }
                catch (IndexOutOfRangeException ex)  // handling programmer-defined exception
                {
                    Console.WriteLine("Exception: Number should be between 0 and 5.");
                }
                catch (Exception ex)  // handling exception form different code
                {
                    Console.WriteLine("An exception was thrown: " + ex.Message);
                }
                finally
                {
                    Console.WriteLine("Thank you\n");
                }
            }
        }

        static void ThrowExceptionWithCode(int code)
        {
            throw new MyCustomException("Some error") { ErrorCode = code };
        }

        static void ExceptionFilters()
        {
            try
            {
                ThrowExceptionWithCode(405);
            }
            catch (MyCustomException ex) when (ex.ErrorCode == 405)
            {
                Console.WriteLine("Handling specific exception based on filter");
            }
            catch (MyCustomException ex)
            {
                Console.WriteLine("Handling generic exception");
            }
        }

        static void ThrowAnException(string message)
        {
            throw new MyCustomException(message);
        }

        static void HandleAndThrowAgain()
        {
            try
            {
                ThrowAnException("test 1");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Log exception " + ex.Message + " and throw again");
                throw ex;
            }
        }

        static void HandleAndThrowWithInnerException()
        {
            try
            {
                ThrowAnException("test 2");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Log exception " + ex.Message + " and throw again");
                throw new AnotherCustomException("throw with inner exception", ex);
            }
        }

        static void HandleAndRethrow()
        {
            try
            {
                ThrowAnException("test 3");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Log exception " + ex.Message + " and rethrow");
                throw;
            }
        }

        static bool MyFilter(Exception ex)
        {
            Console.WriteLine("Just log exception " + ex.Message);
            return false;
        }

        static void HandleWithFilter()
        {
            try
            {
                ThrowAnException("test 4");
            }
            catch (Exception ex) when(MyFilter(ex))
            {
                Console.WriteLine("never invoked");
            }
        }

        static void HandleAll()
        {
            var methods = new Action[]
            {
                HandleAndThrowAgain,
                HandleAndThrowWithInnerException,
                HandleAndRethrow,
                HandleWithFilter
            };

            foreach (var m in methods)
            {
                try
                {
                    m();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    Console.WriteLine(ex.StackTrace);
                    if (ex.InnerException != null)
                    {
                        Console.WriteLine("\tInner exception " + ex.InnerException.Message);
                        Console.WriteLine(ex.InnerException.StackTrace);
                    }
                    Console.WriteLine();
                }
            }
        }

        static void Main(string[] args)
        {
            //TryCatchFinallyBasic();

            //NumberWithTry("5");
            //NumberWithTry("S");
            //NumberWithTry("123456787451684651684631534168");

            //NumberElegant("5");
            //NumberElegant("S");
            //NumberElegant("123456787451684651684631534168");

            //BestPractice();

            //ExceptionFilters();

            HandleAll();
        }
    }
}
