﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lecture08
{
    public class AnotherCustomException : Exception
    {
        public AnotherCustomException(string message, Exception innerException) : base(message, innerException)
        {

        }
    }
}
