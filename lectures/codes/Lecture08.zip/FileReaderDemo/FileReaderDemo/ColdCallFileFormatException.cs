﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FileReaderDemo
{
    class ColdCallFileFormatException : Exception
    {
        public ColdCallFileFormatException(string message) : base(message) { }

        public ColdCallFileFormatException(string message, Exception innerException) : base(message, innerException) { }
    }
}
