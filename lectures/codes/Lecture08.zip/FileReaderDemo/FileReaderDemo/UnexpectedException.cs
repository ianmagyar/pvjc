﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FileReaderDemo
{
    class UnexpectedException : Exception
    {
        public UnexpectedException(string message) : base(message) { }

        public UnexpectedException(string message, Exception innerException) : base(message, innerException) { }
    }
}
