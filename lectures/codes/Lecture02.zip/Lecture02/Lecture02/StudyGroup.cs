﻿namespace Lecture02
{
    public class StudyGroup
    {
        private string code;
        private Student[] students;
        // private List<Student> students;
        private int capacity;

        public StudyGroup(string code, int capacity)
        {
            this.code = code;
            students = new Student[capacity];
            // students = new List<Student>();
            this.capacity = capacity;
        }

        public void AddStudent(Student newStudent)
        {
            /*
            if (students.Count < capacity) {
                students.Add(newStudent);
            }
            */
            for (int i = 0; i < capacity; i++)
            {
                if (students[i] == null)
                {
                    students[i] = newStudent;
                }
            }
        }

        private void ShuffleStudents()
        {
            // move students to front
            for (int i = 1; i < capacity; i++)
            {
                if (students[i - 1] == null)
                {
                    students[i - 1] = students[i];
                    students[i] = null;
                }
            }
        }

        public void RemoveStudent(Student student)
        {
            /*
            if (students.Contains(student)) {
                students.Remove(student);
            }
            */
            for (int i = 0; i < capacity; i++)
            {
                if (students[i] == student)
                {
                    students[i] = null;
                    ShuffleStudents();
                }
            }
        }

        public List<Student> GetStudents()
        {
            // return students;
            return students.ToList();
        }
    }
}
