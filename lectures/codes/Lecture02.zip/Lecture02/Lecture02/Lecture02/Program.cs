﻿using System;

namespace Lecture02
{
    class Program
    {
        static void Main(string[] args)
        {

            Student student1 = new Student();

            Console.WriteLine(student1.Age);
            //pouzitie gettra

            Console.WriteLine("Meno prveho studenta: " + student1.FirstName + " Vek: " + student1.Age);

            //pouzitie settra
            student1.Age = 23;
            student1.FirstName = "Peter";

            Console.WriteLine("Meno prveho studenta: " + student1.FirstName + " Vek: " + student1.Age);

            FontConfig fc = FontConfig.getInstance();

            Console.WriteLine(fc.Color);
        }


    }

    class Student
    {

        //// SLIDE 8 verejna clenska premenna - nespravna implementacia
        //public string FirstName;

        //// SLIDE 8 privatna clenska premenna - spravna implementacia
        //private string FirstName;

        private string firstName, lastName;
        private int age;

        private static int count = 0;

        public Student() : this("", "", 10)
        {

        }

        public Student(string firstName, string lastName, int age)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.age = age;
            Student.count += 1;
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public string FirstName
        {
            get { return this.firstName; }
            set { this.firstName = value; }
        }

        public string LastName
        {
            get { return this.lastName; }
            set { this.lastName = value; this.age = 32; }
        }

    }


    //singleton
    class FontConfig
    {
        private string color = "black";
        private string name = "Helvetica Neu";
        private double size = 48;

        private static FontConfig s_instance = new FontConfig();

        private FontConfig() { }

        public static FontConfig getInstance()
        {
            return s_instance;
        }

        public string Color
        {
            get { return color; }
        }

        public string Name
        {
            get { return name; }
        }

        public double Size
        {
            get { return size; }
        }

    }
}
