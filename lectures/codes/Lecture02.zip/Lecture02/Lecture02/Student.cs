﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture02
{
    public class Student
    {
        private string firstName;
        private string lastName;
        private int grade;

        public Student()
        {

        }

        public Student(string firstName, string lastName)
        {
            Console.WriteLine("calling constructor 2");
            this.firstName = firstName;
            this.lastName = lastName;
            grade = 0;
        }

        //public Student(string firstName)
        //{
        //    this.firstName = firstName;
        //    this.lastName = "Doe";
        //    grade = 0;
        //}

        public Student(string firstName) : this(firstName, "Doe")
        {

        }

        public string GetName()
        {
            return this.firstName + " " + this.lastName;
        }

        public void SetName(string lastName)
        {
            this.lastName = lastName;
        }
    }
}
