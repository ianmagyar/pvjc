﻿namespace Lecture02
{
    public class Student
    {
        private string firstName;
        private string familyName;
        private int grade;

        public Student(string firstName, string familyName)
        {
            this.firstName = firstName;
            this.familyName = familyName;
            grade = 65;
        }

        public void Study()
        {
            grade += 10;
            if (grade > 100)
            {
                grade = 100;
            }
        }
    }
}
