﻿namespace Lecture02
{
    public class Student
    {
        private int id;
        private string firstName;
        private string lastName;
        private int grade;
        private int age;
        public string Program { get; set; } = "Inteligentné systémy";
        private static int counter = 1;

        public string Name
        {
            get
            {
                return this.firstName + " " + this.lastName;
            }
            set
            {
                this.lastName = value;
            }
        }

        public int Age
        {
            get => age;
            set => age = value;
        }

        public Student()
        {
            Console.WriteLine("calling constructor 1");
            firstName = "";
            lastName = "";
            grade = 0;
            age = 18;
            id = counter;
            counter++;
        }

        public Student(string firstName, string lastName, int age)
        {
            Console.WriteLine("calling constructor 2");
            this.firstName = firstName;
            this.lastName = lastName;
            grade = 0;
            this.age = age;
            id = counter;
            counter++;
        }

        /*public Student(string firstName)
        {
            Console.WriteLine("calling constructor 3");
            this.firstName = firstName;
            this.lastName = "Doe";
            grade = 0;
        }*/

        public Student(string firstName) : this(firstName, "Doe", 18)
        {
            Console.WriteLine("calling constructor 3");
            // this(firstName, "Doe");
        }

        public string GetName()
        {
            return firstName + " " + lastName;
        }

        public void SetName(string lastName)
        {
            this.lastName = lastName;
        }

        public void Study()
        {
            grade += 10;
            if (grade > 100)
            {
                grade = 100;
            }
        }
    }
}
