﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture02
{
    public class Singleton
    {
        private static Singleton instance;
        private string value;

        private Singleton()
        {
            value = "abc";
        }

        public string GetValue()
        {
            return this.value;
        }

        public static Singleton GetInstance()
        {
            if (instance == null)
            {
                instance = new Singleton();
            }
            return instance;
        }
    }
}
