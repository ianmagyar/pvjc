﻿namespace Lecture02
{
    public class Program
    {
        static void Main(string[] args)
        {
            StudyGroup group1 = new StudyGroup("C1", 24);
            group1.AddStudent(new Student("John", "Doe"));
            group1.AddStudent(new Student("Jane", "Doe"));
            group1.AddStudent(new Student("Adam", "Smith"));
            group1.AddStudent(new Student("Eva", "Porter"));

            List<Student> students = group1.GetStudents();
            foreach (Student st in students)
            {
                if (st != null)
                {
                    st.Study();
                }
            }
        }
    }
}