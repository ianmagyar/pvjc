﻿namespace Lecture02
{
    public class Program
    {
        static void Main(string[] args)
        {
            StudyGroup group1 = new StudyGroup("C1", 24);
            group1.AddStudent(new Student("John", "Doe", 19));
            group1.AddStudent(new Student("Jane", "Doe", 20));
            group1.AddStudent(new Student("Adam", "Smith", 19));
            group1.AddStudent(new Student("Eva", "Porter", 21));

            Singleton inst = Singleton.GetInstance();
            Console.WriteLine(inst.GetValue());
            Console.WriteLine(inst);
            Singleton inst2 = Singleton.GetInstance();
            Console.WriteLine(inst2.GetValue());
            Console.WriteLine(inst2);
            Console.WriteLine(inst == inst2);
            //Singleton inst2 = new Singleton();
        }
    }
}