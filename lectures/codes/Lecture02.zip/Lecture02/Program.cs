﻿namespace Lecture02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Student st = new Student();
            //Student st2 = new Student("John", "Doe");
            //pretazenie konstruktorov
            Student st1 = new Student();
            Console.WriteLine("St1's name is: " + st1.GetName());

            Student st2 = new Student("Janko", "Hrasko");
            Console.WriteLine("St2's name is: " + st2.GetName());

            Student st3 = new Student("Jane");
            Console.WriteLine("St3's name is: " + st3.GetName());


        }
    }
}